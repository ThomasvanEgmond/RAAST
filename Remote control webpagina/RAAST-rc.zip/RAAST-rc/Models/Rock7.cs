﻿using System;

namespace Remote_Control.Models
{
    public class Rock7
    {
        public string _context;
        public string _id;
        public string _type;

        public int hydra_totalItems;
        public Rock7Data[] hydra_member = new Rock7Data[0];
    }
}
