﻿using Microsoft.EntityFrameworkCore;
using Remote_Control.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Remote_Control.Models;

namespace Remote_Control.Models
{
    public class Database : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Log> Log { get; set; }
        public DbSet<Remote_Control_Data> RemoteControlData { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //herewedefinethenameofourdatabase(makesuretoputthecorrectpassword)
            optionsBuilder.UseNpgsql("UserID=raast;Password=password;Host=127.0.0.1;Port=9005;Database=database;Pooling=true;");
        }
    }
}
