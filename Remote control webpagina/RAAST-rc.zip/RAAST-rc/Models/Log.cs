﻿using Remote_Control.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public enum types
    {
        type1, type2, type3, type4
    }
    public class Log
    {
        public int id { get; set; }
        public string dateTime { get; set; }
        public int userID { get; set; }
        public types types {get; set;}
        public int RemoteControlDataID { get; set; }

        public Log()
        {
            dateTime = DateTime.Now.ToString("yyyy-M-d H:mm");
        }
    }

    public class LogDisplay
    {
        public int id { get; set; }
        public string dateTime { get; set; }
        public User user { get; set; }
        public types types { get; set; }
        public Remote_Control_Data RemoteControlData { get; set; }

        
    }
}
