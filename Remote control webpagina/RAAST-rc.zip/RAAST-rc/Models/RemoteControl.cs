﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public class RemoteControl
    {
        public string _context;
        public string _id;
        public string _type;

        public int hydra_totalItems;
        public RemoteControlData[] hydra_member = new RemoteControlData[0];
    }
}
