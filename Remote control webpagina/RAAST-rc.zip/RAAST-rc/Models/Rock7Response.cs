﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public class Rock7Response
    {
        public Rock7Data lastEntry = null;
        public Rock7Data[] allEntries = new Rock7Data[0];
        public bool isOutsideChallengeZone = false;
    }
}
