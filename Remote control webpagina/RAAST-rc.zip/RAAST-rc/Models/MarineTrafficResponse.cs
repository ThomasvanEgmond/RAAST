﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public class MarineTrafficResponse
    {
        public MarineTrafficData lastEntry = null;
        public MarineTrafficData[] allEntries = new MarineTrafficData[0];
    }
}
