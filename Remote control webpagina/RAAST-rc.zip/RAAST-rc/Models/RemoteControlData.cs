﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public class RemoteControlData
    {
        public string _id;
        public string _type;
        public int? id;

        public string dateSent;
        public float? destLat;
        public float? destLon;
        public string route;
        public int? maxHeel;
        public int? rudder;
        public int? sail;
        public int? course;
        public int? controlLevel;
        public bool? recalibrate;
    }
}
