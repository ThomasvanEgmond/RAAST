﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public class MarineTrafficData
    {
        public string _id;
        public string _type;
        public int id;

        public float? mmsi;
        public float? imo;
        public float? shipId;
        public float? lat;
        public float? lon;
        public float? speed;
        public float? heading;
        public float? course;
        public float? status;
        public string timestamp;
        public string dsrc;
        public string utcSeconds;
        public string shipName;
        public float? shipType;
        public string callSign;
        public string flag;
        public float? length;
        public float? width;
        public float? grt;
        public float? dwt = 0;
        public float? draught;
        public float? yearBuilt;
        public float? rot;
        public string typeName;
        public string aisTypeSummary;
        public string destination;
        public string eta;
    }
}
