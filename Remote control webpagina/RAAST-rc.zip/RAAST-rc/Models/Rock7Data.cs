﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Models
{
    public class Rock7Data
    {
        public string _id;
        public string _type;
        public int? id;
        public string dateReceived;
        public string dateSent;
        public float? curLat;
        public float? curLon;
        public float? destLat;
        public float? destLon;
        public float? seaTemp;
        public float? acidity;
        public float? sailinity;
        public int? maxHeel;
        public int? rudder;
        public int? maxRudder;
        public int? sail;
        public int? course;
        public int? heading;
        public int? windDirection;
        public float? windSpeed;
        public float? speed;
        public float? maxSpeed;
        public int? controlLevel;
        public bool? recalibrate;
    }
}
