using System;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Remote_Control
{
    public enum HttpTarget
    {
        Rock7, RemoteControl, MarineTraffic, OpenData, digital_twin
    }

    public class HTTPRequest
    {
        //Base url to the target so users dont have to type it out every time they want to use it
        private static string baseUrl = "https://transceiver.hr.nl";

        //The API requires different bearer codes based on the target. This functions gives you the code based on your selected target
        private static string GetAuthorizationCodeForTarget(HttpTarget target)
        {
            string code = "55cf01fd002fdad6e0744589b64f0a34a6b6a8914803cf7b3bfe80345d612f4b5fea1f6822faf52dbd26c4fbd4b0695a3dcd5a5dcd46612c12e1176a";

            //switch (target)
            //{
            //    case HttpTarget.Rock7:
            //        code = "55cf01fd002fdad6e0744589b64f0a34a6b6a8914803cf7b3bfe80345d612f4b5fea1f6822faf52dbd26c4fbd4b0695a3dcd5a5dcd46612c12e1176a";
            //        break;
            //    case HttpTarget.RemoteControl:
            //        code = "414c9b88a4cdd79ab063d41dc5861d42286a5e1f73b1482c516a5270b9f8b70193cb0a0df3b626562de83022b6d469028a9258431e80107fdeebb0fe";
            //        break;
            //    case HttpTarget.MarineTraffic:
            //        code = "bcd397e5ffaa0c8486119e8515c121eafc974dd607d12a123262d2184002f29cecc23a8e058ebb34da163694d4c77db9a46ced95a7f3ff5c763071ad";
            //        break;
            //    case HttpTarget.OpenData:
            //        code = "f34c18a7548aa2b0d2af36a57fc3d4b0231c36b18e65e838024242b4fa9ec22ce814068f44af127a28f8ee0a60113cee74132f67b5c54877a13076c0";
            //        break;
            //    case HttpTarget.digital_twin:
            //        code = "e677b29e00d96783249bef437ca8de0ad09df05caa98dc2e58f037b7219de237ca068f3ffda2cf84360733be8d436e5ffadf59505284076ccc3b46c0";
            //        break;
            //    default:
            //        break;
            //}

            return code;
        }

        //Create a HttpClient with custom default settings
        private static HttpClient GetClient(HttpTarget target)
        {
            //Create an HttpClient with the correct SSL validation
            HttpClientHandler clientHandler = new HttpClientHandler();
            clientHandler.ServerCertificateCustomValidationCallback = (message, cert, chain, sslPolicyErrors) =>
            {
                return true;
            };
            HttpClient client = new HttpClient(clientHandler);

            //set authorization and base url
            var authorizationCode = GetAuthorizationCodeForTarget(target);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authorizationCode);
            client.BaseAddress = new Uri(baseUrl);

            //If mediaType is missing add it
            MediaTypeWithQualityHeaderValue mediaType = new MediaTypeWithQualityHeaderValue("application/ld+json");
            if (!client.DefaultRequestHeaders.Accept.Contains(mediaType))
            {
                client.DefaultRequestHeaders.Accept.Add(mediaType);
            }

            return client;
        }

        //A simple Get request that returns the result
        public static async Task<string> Get(HttpTarget target, string url)
        {
            //Create a HttpClient
            HttpClient client = GetClient(target);
            //Try and execute the request
            try
            {
                //execute the request
                HttpResponseMessage response = await client.GetAsync(url);
                //fail the request fails or returns with a different code then 200
                response.EnsureSuccessStatusCode();
                //return the response
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception e)
            {
                return "An error occurded: " + e.Message + "<p style='margin-left:50px'>->" + e.InnerException + "</p><p style='margin-top:25px;'>" + e.StackTrace + "</p>";
            }
        }

        //A simple Post request that returns the result
        public static async Task<string> Post(HttpTarget target, string url, string json)
        {
            //Create a HttpClient
            HttpClient client = GetClient(target);

            //Try and execute the request
            try
            {
                //Set the correct request data (type, url and data)
                HttpRequestMessage httpRequest = new HttpRequestMessage(HttpMethod.Post, url)
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json")
                };

                //execute the request
                HttpResponseMessage response = await client.SendAsync(httpRequest);
                //fail the request fails or returns with a different code then 200
                response.EnsureSuccessStatusCode();
                //return the response
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception e)
            {
                return "An error occurded: " + e.Message + "<p style='margin-left:50px'>->" + e.InnerException + "</p><p style='margin-top:25px;'>" + e.StackTrace + "</p>";
            }
        }
    }
}
