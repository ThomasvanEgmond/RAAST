﻿using Remote_Control.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Classes
{
    public static class GlobalVariables
    {
        public static readonly int updateDelayInMinutes = 0;

        public static DateTime rock7Time = DateTime.MinValue;
        public static Rock7Response rock7Data;

        public static DateTime marineTrafficTime = DateTime.MinValue;
        public static MarineTrafficResponse marineTrafficData;
        public static User user = null;


        public static float[][] finishLine = new float[][] {
            new float[] { 55, -16.0f},
            new float[] { 55, -16.0f },
            new float[] { 55, -16.0f },
            new float[] { 51, -16.0f },
            new float[] { 46, -11.0f },
            new float[] { 44.5f, -13.5f },
            new float[] { 37, -13.5f },
            new float[] { 35, -20.5f },
            new float[] { 25, -22f }
        };
        public static float[][] startLine = new float[][]
        {
            new float[] { 48.0f, -47.0f },
            new float[] { 45.5f, -47.0f },
            new float[] { 40.0f, -65.0f },
            new float[] { 30.0f, -77.0f },
            new float[] { 20.0f, -59.0f },
            new float[] { 10.0f, -56.0f },
        };
    }
}
