﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using Newtonsoft.Json;
using System.Text;

namespace Remote_Control.Classes
{
    public class FileManager
    {
        private static string basePath = "wwwroot";

        public static void SetBasePath(string path)
        {
            basePath = path;
        }

        public static string GetBasePath()
        {
            return basePath;
        }

        #region Files
        public static bool FileExists(string name, string extraPath = "")
        {
            string path = basePath + "/" + extraPath + name;
            return File.Exists(path);
        }

        public static FileStream OpenFile(string name, string extraPath = "")
        {
            string path = basePath + "/" + extraPath + name;

            return File.Open(path, FileMode.OpenOrCreate);
        }

        public static void CloseFile(FileStream file)
        {
            file.Close();
        }

        public static string[] GetFiles(string extraPath = "")
        {
            string path = basePath + "/" + extraPath;
            return Directory.GetFiles(path);
        }

        public static void WriteFile<T>(FileStream file, T classData, bool shouldClose = true)
        {
            file.SetLength(0);
            file.Write(Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(classData)));

            if (shouldClose)
            {
                CloseFile(file);
            }
        }

        public static T ReadFile<T>(FileStream file, bool shouldClose = true)
        {
            byte[] buffer = new byte[file.Length];
            file.Read(buffer);

            string rawData = Encoding.ASCII.GetString(buffer);

            T data = JsonConvert.DeserializeObject<T>(rawData);
            if (shouldClose)
            {
                CloseFile(file);
            }

            return data;
        }

        public static bool DeleteFile(string name, string extraPath = "")
        {
            string path = basePath + "/" + extraPath + name;
            if (File.Exists(path))
            {
                File.Delete(path);
                return true;
            }
            return false;
        }
        #endregion

        #region Directories
        public static bool DirectoryExists(string name, string extraPath = "")
        {
            string path = basePath + "/" + extraPath + name;
            return Directory.Exists(path);
        }

        public static DirectoryInfo CreateDirectory(string name, string extraPath = "")
        {
            string path = basePath + "/" + extraPath + name;

            return Directory.CreateDirectory(path);
        }

        public static bool DeleteDirectory(string name, string extraPath = "")
        {
            string path = basePath + "/" + extraPath + name;
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
                return true;
            }
            return false;
        }

        public static string[] GetDirectories(string extraPath = "")
        {
            string path = basePath + "/" + extraPath;
            return Directory.GetDirectories(path);
        }
        #endregion
    }
}
