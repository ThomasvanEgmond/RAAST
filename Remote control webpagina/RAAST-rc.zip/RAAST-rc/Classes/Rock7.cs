﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Classes
{
    public class Rock7
    {
        public int id { get; set; }
        public string direction { get; set; }
        public string dateReceived { get; set; }
        public string dateSent { get; set; }
        public float curLat { get; set; }
        public float curLon { get; set; }
        public float destLat { get; set; }
        public float destLon { get; set; }
        public float seaTemp { get; set; }
        public float acidity { get; set; }
        public float sailinity { get; set; }
        public int maxHeel { get; set; }
        public int rudder { get; set; }
        public int maxRudder { get; set; }
        public int sail { get; set; }
        public int course { get; set; }
        public int heading { get; set; }
        public int windDirection { get; set; }
        public float windSpeed { get; set; }
        public float speed { get; set; }
        public float maxSpeed { get; set; }
        public int controlLevel { get; set; }
        public bool recalibrate { get; set; }
    }
}
