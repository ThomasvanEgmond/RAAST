﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Classes
{

    public class Remote_Control_Data : Remote_Control_Data_api
    {
        public int id { get; set; }
    }

    public class Remote_Control_Data_api 
    {
        public string dateSent { get; set; }
        public float? destLat { get; set; }
        public float? destLon { get; set; }
        public string route { get; set;}
        public int? maxHeel { get; set; }
        public int? rudder { get; set; }
        public int? sail { get; set; }
        public int? course { get; set; }
        public int? controlLevel { get; set; }
        public bool? recalibrate { get; set; }

        public Remote_Control_Data_api()
        {
            dateSent = DateTime.Now.ToString("yyyy-M-d H:mm");
            destLat = null;
            destLon = null;
            route = null;
            maxHeel = null;
            rudder = null;
            sail = null;
            course = null;
            controlLevel = null;
            recalibrate = null;
        }

        public void unNulData()
        {
            if (destLat == null)
            {
                destLat = 0;
            }
            if (destLon == null)
            {
                destLon = 0;
            }
            if (route == null)
            {
                route = "";
            }
            if (maxHeel == null)
            {
                maxHeel = 0;
            }
            if (rudder == null)
            {
                rudder = 0;
            }
            if (sail == null)
            {
                sail = 0;
            }
            if (course == null)
            {
                course = 0;
            }
            if (recalibrate == null)
            {
                recalibrate = false;
            }
        }
    }
}