﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

//Convert response data to useable data
function getDataFromResponse(response) {
    //prepare variables
    var keys = [];
    var values = [];
    var data = response;

    //Filter response data and store the result
    for (var i = 0; i < data.length; i++) {
        if (i == 0) { keys = Object.keys(data[i]); }

        values[i] = Object.values(data[i]);
        values[i] = values[i].splice(2, values[i].length);
    }
    keys = keys.splice(2, keys.length);

    //Generate table headers
    var resHead = "<tr>";
    for (var i = 0; i < keys.length; i++) {
        resHead += "<th style='padding: 5px;'>" + keys[i] + "</th>";
    }
    resHead += "</tr>";

    //Generate table body
    var resBody = "";
    for (var i = 0; i < values.length; i++) {
        resBody += "<tr>";
        for (var r = 0; r < values[i].length; r++) {
            resBody += "<td style='padding: 5px;'>" + values[i][r] + "</td>";
        }
        resBody += "</tr>";
    }

    //return results
    return { "thead": resHead, "tbody": resBody, "keys": keys, "values": values };
}