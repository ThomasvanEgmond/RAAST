﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Remote_Control.Classes;
using Remote_Control.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Controllers
{
    public class DesignController : Controller
    {
        public IActionResult Index()
        {
            if (GlobalVariables.user == null || !GlobalVariables.user.isAdmin) return RedirectToAction("login", "authentication");
            string jsonRaw = HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7s").Result;
            dynamic temp = JsonConvert.DeserializeObject(jsonRaw);
            ViewBag.rock7Data = temp["hydra:member"];
            return View();
        }
    }
}
