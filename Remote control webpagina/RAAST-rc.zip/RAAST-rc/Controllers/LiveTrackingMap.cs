﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Remote_Control.Classes;
using Remote_Control.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Controllers
{
    public class LiveTrackingMap : Controller
    {
        public IActionResult Index()
        {
            ViewBag.finishLine = JsonConvert.SerializeObject(GlobalVariables.finishLine);
            ViewBag.startLine = JsonConvert.SerializeObject(GlobalVariables.startLine);
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
