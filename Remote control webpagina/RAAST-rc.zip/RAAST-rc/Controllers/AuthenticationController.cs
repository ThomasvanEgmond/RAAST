﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Remote_Control.Models;
using Remote_Control.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Remote_Control.Controllers
{
    public class AuthenticationController : Controller
    {
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User objUser)
        {
            if (ModelState.IsValid)
            {
                using (var db = new Database())
                {
                    var obj = db.Users.Where(a => a.username.Equals(objUser.username) && a.password.Equals(objUser.password)).FirstOrDefault();
                    if (obj != null)
                    {
                        GlobalVariables.user = obj;
                        return RedirectToAction("index", "home");
                    }
                }
            }
            return View(objUser);
        }
    }
}
