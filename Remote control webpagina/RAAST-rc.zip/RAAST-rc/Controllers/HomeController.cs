﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Remote_Control.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Remote_Control.Classes;
using System.IO;
using System.Text;

namespace Remote_Control.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        public IActionResult Index()
        {
            //using (var db = new Database())
            //{
            //    User user = new User()
            //    {
            //        username = "nameless",
            //        password = "king",
            //        isAdmin = true
            //    };
            //    var a = db.Users.Add(user);
            //    var b = db.SaveChanges();
            //}
            if (GlobalVariables.user == null || !GlobalVariables.user.isAdmin) return RedirectToAction("login", "authentication");

            return RedirectToAction("index", "design");

            //get tranceiver data(rock7s)
            //string jsonRaw = HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7s").Result;

            //JObject jsonObj = JObject.Parse(jsonRaw);
            //Dictionary<string, string> dictObj = jsonObj["hydra:member"][0].ToObject<Dictionary<string, string>>();

            ////send data to the frontend (rock7s)
            //ViewBag.keys = dictObj.Keys;
            //ViewBag.data = jsonObj["hydra:member"];

            ////get tranceiver data (remote control)
            //jsonRaw = HTTPRequest.Get(HttpTarget.RemoteControl, "/api/remote_controls").Result;
            //jsonObj = JObject.Parse(jsonRaw);
            //dictObj = jsonObj["hydra:member"][0].ToObject<Dictionary<string, string>>();

            ////send data to the frontend (remote control)
            //ViewBag.remoteControlKeys = dictObj.Keys;
            //ViewBag.remoteControl = jsonObj["hydra:member"];



            //return View();
        }

        public IActionResult Type1()
        {
            string jsonRaw = HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7s").Result;
            dynamic temp = JsonConvert.DeserializeObject(jsonRaw);
            ViewBag.data = temp["hydra:member"];

            return View("Type1");
        }

        public IActionResult Type2()
        {
            string jsonRaw = HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7s").Result;
            dynamic temp = JsonConvert.DeserializeObject(jsonRaw);
            ViewBag.data = temp["hydra:member"];

            return View("Type2");
        }
        public IActionResult Type3()
        {
            string jsonRaw = HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7s").Result;
            dynamic temp = JsonConvert.DeserializeObject(jsonRaw);
            ViewBag.data = temp["hydra:member"];

            return View("Type3");
            
        }
                public IActionResult Type4()
        {
            string jsonRaw = HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7s").Result;
            dynamic temp = JsonConvert.DeserializeObject(jsonRaw);
            ViewBag.data = temp["hydra:member"];

            return View("Type4");
        }

        public IActionResult LogDisplay()
        {
            if (GlobalVariables.user == null || !GlobalVariables.user.isAdmin) return RedirectToAction("login", "authentication");
            List<LogDisplay> display = new List<LogDisplay>();
            using (var db = new Database())
            {
                foreach (var item in db.Log.ToList())
                {
                    Log s = item;
                    var obj = db.Users.Where(a => a.id == item.userID).FirstOrDefault();
                    var obj1 = db.RemoteControlData.Where(a => a.id == item.RemoteControlDataID).FirstOrDefault();
                    LogDisplay l = new LogDisplay()
                    {
                        id = s.id,
                        user = obj,
                        dateTime = s.dateTime,
                        RemoteControlData = obj1,
                        types = s.types
                    };
                    display.Add(l);
                }
            }
            var newList = display.OrderByDescending(x => x.id).ToList();

            return View(newList);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public async Task<string> Type1P(int k = 0, int i = 0)
        {
            Remote_Control_Data rc = null;
            if (Request == null)
            {
                if (k == 0 && i == 0) return "";
                if (k < 0 || i < 0 || i > 359 || k > 359) return "";
                rc = new Remote_Control_Data
                {
                    rudder = k,
                    sail = i
                };
                return JsonConvert.SerializeObject(rc);
            }
            else
            {
                if (Request.Form.Count == 0) return "";
                dynamic temp = JsonConvert.DeserializeObject(Request.Form.Keys.ToList()[0]);
                if (temp["i1"] == null || temp["i2"] == null) return "";
                if (temp["i1"] < 0 || temp["i2"] < 0 || temp["i1"] > 359 || temp["i2"] > 359) return "";
                rc = new Remote_Control_Data
                {
                    rudder = temp["i1"],
                    sail = temp["i2"],
                    controlLevel = temp["controlLevel"],
                    recalibrate = temp["recalibrate"]
                };
            }
            Remote_Control_Data_api rcda = new Remote_Control_Data_api() { sail = rc.sail, rudder = rc.rudder, controlLevel = rc.controlLevel, recalibrate = rc.recalibrate};
            try
            {
                // using (var db = new Database())
                // {
                rc.unNulData();
                //     db.RemoteControlData.Add(rc);
                //     db.SaveChanges();
                //     Log l = new Log()
                //     {
                //         types = types.type1,
                //         userID = GlobalVariables.user.id,
                //         RemoteControlDataID = rc.id
                //     };
                //     var f = db.Log.Add(l);
                //     db.SaveChanges();
                // }
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.NullValueHandling = 0;

                return await HTTPRequest.Post(HttpTarget.RemoteControl, "/api/remote_controls", JsonConvert.SerializeObject(rcda, settings) );

            }
            catch (Exception)
            {
                return "";
            }
        }

        [HttpPost]
        public async Task<string> Type2P(int i)
        {
            Remote_Control_Data rc = null;
            if (Request == null)
            {
                //if (i == 0) return "";
                //if (i < 0 || i > 359) return "";
                rc = new Remote_Control_Data
                {
                    course = i
                };
                return JsonConvert.SerializeObject(rc);
            }
            else
            {
                if (Request.Form.Count == 0) return "";
                dynamic temp = JsonConvert.DeserializeObject(Request.Form.Keys.ToList()[0]);
                if (temp["course"] == null) return "";
                if (temp["course"] < 0 || temp["course"] > 359) return "";
                rc = new Remote_Control_Data
                {
                    course = temp["course"],
                    controlLevel = temp["controlLevel"],
                    recalibrate = temp["recalibrate"]
                };
            }
            try
            {
                // using (var db = new Database())
                // {
                rc.unNulData();
                //     db.RemoteControlData.Add(rc);
                //     db.SaveChanges();
                //     Log l = new Log()
                //     {
                //         types = types.type2,
                //         userID = GlobalVariables.user.id,
                //         RemoteControlDataID = rc.id
                //     };
                //     var f = db.Log.Add(l);
                //     db.SaveChanges();
                // }
                Remote_Control_Data_api rcda = new Remote_Control_Data_api() { course = rc.course, controlLevel = rc.controlLevel, recalibrate = rc.recalibrate };
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.NullValueHandling = 0;

                return await HTTPRequest.Post(HttpTarget.RemoteControl, "/api/remote_controls", JsonConvert.SerializeObject(rcda, settings));
            }
            catch (Exception e)
            {
                return e.Message + " \n\n " + e.StackTrace;
            }
        }

        [HttpPost]
        public async Task<string> Type3P(float k = 0, float i = 0)
        {
            Remote_Control_Data rc = null;
            if (Request == null)
            {
                if (k == 0 && i == 0) return "";
                rc = new Remote_Control_Data
                {
                    destLat = k,
                    destLon = i
                };
                // System.Console.WriteLine("first if: " + rc);
                return JsonConvert.SerializeObject(rc);
            }
            else
            {
                if (Request.Form.Count == 0) return "";
                dynamic temp = JsonConvert.DeserializeObject(Request.Form.Keys.ToList()[0]);
                if (temp["destLat"] == null || temp["destLon"] == null) return "";
                rc = new Remote_Control_Data
                {
                    destLat = temp["destLat"],
                    destLon = temp["destLon"],
                    controlLevel = temp["controlLevel"],
                    recalibrate = temp["recalibrate"]
                };
            }
            Remote_Control_Data_api rcda = new Remote_Control_Data_api() { destLat = rc.destLat, destLon = rc.destLon, controlLevel=rc.controlLevel, recalibrate=rc.recalibrate};
        
            try
            {
                // using (var db = new Database())
                // {
                    
                rc.unNulData();
                //     db.RemoteControlData.Add(rc);
                //     db.SaveChanges();
                //     Log l = new Log()
                //     {
                //         types = types.type3,
                //         userID = GlobalVariables.user.id,
                //         RemoteControlDataID = rc.id
                //     };
                //     var f = db.Log.Add(l);
                //     db.SaveChanges();
                // }
    
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.NullValueHandling = 0;

                return await HTTPRequest.Post(HttpTarget.RemoteControl, "/api/remote_controls", JsonConvert.SerializeObject(rcda, settings));
            }
            catch (Exception e)
            {
                return e.Message + " \n\n " + e.StackTrace;
            }
        }

        // Type 4

        [HttpPost]
        public async Task<string> Type4P(string r)
        {
            Remote_Control_Data rc = null;
            if (Request == null)
            {
                rc = new Remote_Control_Data
                {
                    route = r
                };
                return JsonConvert.SerializeObject(rc);
            }
            else
            {
                if (Request.Form.Count == 0) return "";
                dynamic temp = JsonConvert.DeserializeObject(Request.Form.Keys.ToList()[0]);
                if (temp["route"] == null) return "";
                rc = new Remote_Control_Data
                {
                    route = temp["route"],
                    controlLevel = temp["controlLevel"],
                    recalibrate = temp["recalibrate"]
                };
            }
            Remote_Control_Data_api rcda = new Remote_Control_Data_api() { route = rc.route, controlLevel = rc.controlLevel, recalibrate = rc.recalibrate};
            
            try
            {
                // using (var db = new Database())
                // {
                rc.unNulData();
                //     db.RemoteControlData.Add(rc);
                //     db.SaveChanges();
                //     Log l = new Log()
                //     {
                //         types = types.type4,
                //         userID = GlobalVariables.user.id,
                //         RemoteControlDataID = rc.id
                //     };
                //     var f = db.Log.Add(l);
                //     db.SaveChanges();
                // }
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.NullValueHandling = 0;

                return await HTTPRequest.Post(HttpTarget.RemoteControl, "/api/remote_controls", JsonConvert.SerializeObject(rcda, settings) );

            }
            catch (Exception e)
            {
                return e.Message + " \n\n " + e.StackTrace;
            }
        }

        [HttpGet]
        public async Task<string> GetMarineTrafficData()
        {
            TimeSpan ts = DateTime.Now - GlobalVariables.marineTrafficTime;
            //Check if we already have the data stored and if its not expired data
            if (ts.Minutes < GlobalVariables.updateDelayInMinutes && GlobalVariables.marineTrafficData != null)
            {
                //Return stored data
                return JsonConvert.SerializeObject(GlobalVariables.marineTrafficData);
            }
            //Attempt to read data from the api
            try
            {
                //Receive json
                string json = await HTTPRequest.Get(HttpTarget.MarineTraffic, "/api/marine_traffics");
                //The json thats received contains invalid characters (@ and :). We replace these with our own preffered character
                json = json.Replace("@context", "_context")
                    .Replace("@id", "_id")
                    .Replace("@type", "_type")
                    .Replace("hydra:member", "hydra_member")
                    .Replace("hydra:totalItems", "hydra_totalItems");

                //Convert json into object
                MarineTraffic response = JsonConvert.DeserializeObject<MarineTraffic>(json);
                MarineTrafficData[] rows = response.hydra_member;

                //Prepaire data to send to the frontend
                MarineTrafficResponse data = new MarineTrafficResponse();
                if(rows.Length > 0)
                {
                    data.lastEntry = rows[rows.Length - 1];
                }
                data.allEntries = rows;

                //store global variable
                GlobalVariables.marineTrafficData = data;
                //Update global time variable (this resets the time it takes to expire this data)
                GlobalVariables.marineTrafficTime = DateTime.Now;

                //return results
                return JsonConvert.SerializeObject(data);
            }
            catch
            {
                //Upon finding an error return this
                return null;
            }
        }

        [HttpGet]
        public async Task<string> GetRemoteControlData()
        {
            try
            {
                return await HTTPRequest.Get(HttpTarget.RemoteControl, "/api/remote_controls");
            }
            catch
            {
                return "";
            }
        }

        [HttpGet]
        public async Task<string> GetRock7Data()
        {
            TimeSpan ts = DateTime.Now - GlobalVariables.rock7Time;
            
            //Check if we already have the data stored and if its not expired data
            if (ts.Minutes < GlobalVariables.updateDelayInMinutes && GlobalVariables.rock7Data != null)
            {
                //Return stored data
                return JsonConvert.SerializeObject(GlobalVariables.rock7Data);
            }

            //Attempt to read data from the api
            try
            {
                //Receive json
                string json = await HTTPRequest.Get(HttpTarget.Rock7, "/api/rock7/latestIncoming");
                //The json thats received contains invalid characters (@ and :). We replace these with our own preffered character
                //json = json.Replace("@context", "_context")
                //    .Replace("@id", "_id")
                //    .Replace("@type", "_type")
                //    .Replace("hydra:member", "hydra_member")
                //    .Replace("hydra:totalItems", "hydra_totalItems");

                //Convert json into object
                //Models.Rock7 response = JsonConvert.DeserializeObject<Models.Rock7>(json);
                //Rock7Data[] rows = response.hydra_member;

                ////Prepaire data to send to the frontend
                //Rock7Response data = new Rock7Response();
                //if (rows.Length > 0)
                //{
                //    data.lastEntry = rows[rows.Length - 1];
                //}
                //data.allEntries = rows;
                //if (data.lastEntry != null)
                //{
                //    data.isOutsideChallengeZone = IsOutsideChallengeZone(data.lastEntry.curLon ?? 0, data.lastEntry.curLat ?? 0);
                //}

                ////store global variable
                //GlobalVariables.rock7Data = data;
                ////Update global time variable (this resets the time it takes to expire this data)
                GlobalVariables.rock7Time = DateTime.Now;

                //return results
                //return JsonConvert.SerializeObject(data);
                return json;
            }
            catch
            {
                //Upon finding an error return this
                return null;
            }
        }

        [HttpGet]
        public string GetActionQueue()
        {
            FileStream stream = FileManager.OpenFile("ActionQueue.txt");
            try
            {
                if(stream.Length <= 0)
                {
                    FileManager.WriteFile(stream, new RemoteControlData[0], true);
                    stream = FileManager.OpenFile("ActionQueue.txt");
                }
                RemoteControlData[] data = FileManager.ReadFile<RemoteControlData[]>(stream);

                return JsonConvert.SerializeObject(data);
            }
            catch
            {
                FileManager.CloseFile(stream);
                return "";
            }
        }

        [HttpPost]
        public string PostActionQueue(RemoteControlData data = null)
        {
            string rawData = Request?.Form?.Keys != null ? Request.Form.Keys.ToList()[0] : "";
            FileStream stream = FileManager.OpenFile("ActionQueue.txt");
            try
            {
                if(data == null)
                {
                    data = JsonConvert.DeserializeObject<RemoteControlData>(rawData);
                }

                List<RemoteControlData> allData = new List<RemoteControlData>();
                try
                {
                    allData = FileManager.ReadFile<RemoteControlData[]>(stream, false).ToList();
                }
                catch { }
                allData.Add(data);

                FileManager.WriteFile(stream, allData);
                return JsonConvert.SerializeObject(allData);
            }
            catch (Exception e)
            {
                FileManager.CloseFile(stream);
                return e.Message + "  " + e.StackTrace;
            }
        }

        private float[] GetDistanceFromLine(float[][] line, float posX, float posY)
        {
            float[] closestCoords = new float[] { 0, 0, -1 };

            for (int i = 0; i < line.Length; i++)
            {
                float[] coords = line[i];
                float[] diff = new float[] { coords[0] - posX, coords[1] - posY };
                float dist = (diff[0] < 0 ? diff[0] * -1 : diff[0]) + (diff[1] < 0 ? diff[1] * -1 : diff[1]);

                if (dist < closestCoords[2] || closestCoords[2] < 0)
                {
                    closestCoords[0] = coords[0];
                    closestCoords[1] = coords[1];
                    closestCoords[2] = dist;
                }
            }
            return closestCoords;
        }

        private float[][] GetPositionsAlongLine(float[][] line)
        {
            List<float[]> positions = new List<float[]>();
            int i = 0;
            int r = 0;
            for (; i < line.Length - 1; i++)
            {
                r = 0;
                float[] startPos = line[i];
                float[] nextPos = line[i + 1];
                float[] diff = new float[] { startPos[0] - nextPos[0], startPos[1] - nextPos[1] };
                int steps = (int)Math.Ceiling((diff[0] < 0 ? diff[0] * -1 : diff[0]) + (diff[1] < 0 ? diff[1] * -1 : diff[1]));

                //if steps is a negative number turn it into a positive number
                if(steps < 0) { steps *= -1; }
                float[] stepSize = new float[] { diff[0] / steps, diff[1] / steps };

                for (; r < steps; r++)
                {
                    float[] pos = new float[] { startPos[0] - (stepSize[0] * r), startPos[1] - (stepSize[1] * r) };
                    positions.Add(pos);
                }
            }
            positions.Add(line[line.Length - 1]);

            return positions.ToArray();
        }

        private bool IsOutsideChallengeZone(float posX, float posY)
        {
            float[][] startPositions = GetPositionsAlongLine(GlobalVariables.startLine);
            float[][] finishPositions = GetPositionsAlongLine(GlobalVariables.finishLine);

            float[] closestPointStart = GetDistanceFromLine(startPositions, posX, posY);
            float[] closestPointFinish = GetDistanceFromLine(finishPositions, posX, posY);

            //return if the given position is outside the challenge zone (only on a vertical level)
            return (closestPointStart[1] >= posY || closestPointFinish[1] <= posY);
        }
    }
}
