/* CAN to WiFi/4G bridge for LilyGO-T-SIM7000G (ESP32) and MCP2515 module
 * Wouter Bergmann Tiest
 * 23 March 2022
 * 
 * Required libraries:
 * - TinyGSM
 * - ArduinoHttpClient
 * - autowp-arduino-mcp2515
 * - ArduinoJSON
 * 
 * Enter any input within 5 seconds after start-up to enter
 * config mode. Enter NULL as password to connect to unprotected
 * WiFi network. Expects a webserver running on host:port.
 * Config data is stored in flash memory (using EEPROM library).
 * 
 * First tries to connect using WiFi. If this fails, tries GPRS.
 * LED blinking: trying to establish connection
 * LED fixed: connection established
 * 
 * Connections for MCP2515 module:
 * SCK: pin 18
 * MISO: pin 19
 * MOSI: pin 23
 * CS: pin 5
 * 
 * Note: although the MCP2515 chip can run on 3.3V, the TJA1050
 * transceiver chip cannot and requires 5V, so Vcc on the MCP2515 
 * module needs to be connected to Vin_5V on the LilyGO board.
 */

#include <Arduino.h>
#include <EEPROM.h>
#include <Ticker.h>
#include <WiFi.h>
#define TINY_GSM_MODEM_SIM7000
#define TINY_GSM_RX_BUFFER 1024 // Set RX buffer to 1Kb
#include <TinyGsmClient.h>
#include <HttpClient.h>
#include <stdio.h>
//#include <WiFiClientSecure.h>
#include <mcp2515.h>
#include <map>
#include <ArduinoJson.h>
#include <FaBo9Axis_MPU9250.h>
#include <ESP32Servo.h>
#include <queue>
#include "sensorTypes.h"
// #include "certificate.h"

#define SerialMon     Serial // debug console
#define SerialAT      Serial1 // SIM module
#define GSM_PIN       "0000" // SIM pin code
#define BUFFER_SIZE   25
#define DATA_SIZE     1024
#define EEPROM_SIZE   200
#define EEPROM_OK     'W' // magic value
#define WIFI_TIMEOUT  10 // number of retries
#define UART_BAUD     9600
#define PIN_DTR       25
#define PIN_TX        27
#define PIN_RX        26
#define PIN_PWR       4
#define PIN_LED       12
#define PIN_CS        5
#define CAN_BITRATE   CAN_125KBPS
#define SEND_INTERVAL 10000 // ms
#define CAN_PRIO      2
#define CAN_SRC       1
#define CAN_DEST      255
#define toDeg(x)      (180.0f * (x) / PI)
#define toRad(x)      (PI * (x) / 180.0f)

struct {
    char ssid[BUFFER_SIZE];
    char password[BUFFER_SIZE];
    char host[BUFFER_SIZE];
    int port = 1024;
    char useGprs[2] = "N";
    char apn[BUFFER_SIZE];
    char gprsUser[BUFFER_SIZE];
    char gprsPass[BUFFER_SIZE];
} configData;

//WiFiClientSecure wifiClient;
WiFiClient wifiClient;
TinyGsm modem(SerialAT);
TinyGsmClient gprsClient(modem);
bool wifi = false;
bool recalibrating = false;
Client *client; // points to either wifiClient or gprsClient
MCP2515 mcp2515(PIN_CS);

Servo servo;
FaBo9Axis fabo_9axis;

static long lastSent;
static long last_time;
static std::map<PGN, float> sensorData;

volatile int counter = 0;
bool MPU_OK = true;
float Kp = 1;
float Kd = 1;
float PreviousError;
float sample_time = 1;
float theta_r = 0;
float huidigeKoers = 0;
float gewensteKoers = -90;
float pos = 0;
float roerHoek = 0;
float y_cos_last, y_sin_last, x_cos_last, x_sin_last;
float mx_corr = 26.12, my_corr = 76.28, angle_corr = 2.03;
int controlLvl = 0;

std::pair <float, float> curPos(51.897944246279856, 4.418410761595207);
std::pair <float, float> desPos(0, 0);

float alteredValue = 0;
float NoGOrange = 35;
float status = 0;
std::queue<std::pair<float, float>> waypointList;
std::queue<std::pair<float, float>> tempWaypointList;
String side;

void addWayPoint(std::pair<float, float> waypoint);

void blink() {
    static int state = HIGH;
    state = !state;
    digitalWrite(PIN_LED, state);
}

void modemPowerOn() { // pull power pin low for 1 s (Ton in Table 8)
    digitalWrite(PIN_PWR, LOW);
    delay(1000);
    digitalWrite(PIN_PWR, HIGH);
}

void modemPowerOff() { // pull power pin low for at least 1.2 s (Toff in Table 9)
    digitalWrite(PIN_PWR, LOW);
    delay(1500);
    digitalWrite(PIN_PWR, HIGH);
}

void modemRestart() {
    modemPowerOff();
    delay(1000);
    modemPowerOn();
}

void enableGPS(bool gprs) {

    if (!gprs){
        // Set SIM7000G GPIO4 LOW, turn on GPS power
        // CMD:AT+SGPIO=0,4,1,1
        // Only in version 20200415 is there a function to control GPS power
        SerialMon.println("Turning modem on.");
        pinMode(PIN_PWR, OUTPUT);
        modemPowerOn();

        SerialAT.begin(UART_BAUD, SERIAL_8N1, PIN_RX, PIN_TX);

        delay(1000); // Give modem some time to initialise

        while (!modem.testAT()) {
            SerialMon.println("Failed to start modem; restarting.");
            modemRestart();
            SerialAT.begin(UART_BAUD, SERIAL_8N1, PIN_RX, PIN_TX);
            delay(1000);
        }

        SerialMon.println("Modem ready.");

        String name = modem.getModemName();
        SerialMon.println("Modem Name: " + name);

        String modemInfo = modem.getModemInfo();
        SerialMon.println("Modem Info: " + modemInfo);
    }

    modem.sendAT("+SGPIO=0,4,1,1");
    modem.waitResponse(1000);
    modem.enableGPS();
    delay(5000);
}

void disableGPS(void) {
    // Set SIM7000G GPIO4 LOW, turn off GPS power
    // CMD:AT+SGPIO=0,4,1,0
    // Only in version 20200415 is there a function to control GPS power
    modem.sendAT("+SGPIO=0,4,1,0");
    modem.waitResponse(1000);
    modem.disableGPS();
}

// valueLoaded = true when a default value is stored in value
void getInput(const char *name, char *value, bool valueLoaded) {
    SerialMon.print(name);
    if (valueLoaded) {
        SerialMon.print(" [");
        SerialMon.print(value);
        SerialMon.print(']');
    }
    SerialMon.println('?');
    String resp = SerialMon.readStringUntil('\n');
    resp.trim();
    if (resp.length()) resp.toCharArray(value, BUFFER_SIZE);
}

void config(bool valueLoaded) {
    if (valueLoaded) {
        EEPROM.get(1, configData);  
        SerialMon.println("Press <Enter> to keep values");
    }
    getInput("SSID", configData.ssid, valueLoaded);
    getInput("Password", configData.password, valueLoaded);
    getInput("GPRS as backup Y/N", configData.useGprs, valueLoaded);
    *configData.useGprs = toupper(*configData.useGprs);
    if (*configData.useGprs == 'Y') {
        getInput("APN", configData.apn, valueLoaded);
        getInput("GPRS username", configData.gprsUser, valueLoaded);
        getInput("GPRS password", configData.gprsPass, valueLoaded);
    }
    getInput("Host", configData.host, valueLoaded);
    char buffer[BUFFER_SIZE];
    snprintf(buffer, BUFFER_SIZE, "%d", configData.port);
    getInput("Port", buffer, true);
    configData.port = atoi(buffer);
    EEPROM.put(1, configData);
    EEPROM.write(0, EEPROM_OK);
    EEPROM.commit();
    
}



bool connectWifi() {
    SerialMon.print("\nConnecting to WiFi network ");
    SerialMon.print(configData.ssid);
    if (!strncmp(configData.password, "NULL", BUFFER_SIZE)) {
        WiFi.begin(configData.ssid);
    } else {
        WiFi.begin(configData.ssid, configData.password);
    }

    int timeOut = 0;
    while (WiFi.status() != WL_CONNECTED && (timeOut < WIFI_TIMEOUT || *configData.useGprs != 'Y')) {
        delay(500);
        SerialMon.print(".");
        timeOut++;
    }
    if (WiFi.status() == WL_CONNECTED) {
        SerialMon.print("\nConnected, IP address: ");
        SerialMon.println(WiFi.localIP());
        return true;
    } else {
        SerialMon.println("\nCould not connect using WiFi; trying GPRS.");
        return false;
    }
}

bool connectGprs() {
    SerialMon.println("Turning modem on.");
    pinMode(PIN_PWR, OUTPUT);
    modemPowerOn();

    SerialAT.begin(UART_BAUD, SERIAL_8N1, PIN_RX, PIN_TX);

    delay(1000); // Give modem some time to initialise

    while (!modem.testAT()) {
        SerialMon.println("Failed to start modem; restarting.");
        modemRestart();
        SerialAT.begin(UART_BAUD, SERIAL_8N1, PIN_RX, PIN_TX);
        delay(1000);
    }

    SerialMon.println("Modem ready.");

    String name = modem.getModemName();
    SerialMon.println("Modem Name: " + name);

    String modemInfo = modem.getModemInfo();
    SerialMon.println("Modem Info: " + modemInfo);

    enableGPS(true);

    // set full functionality
    if (!modem.setPhoneFunctionality(1)) {
        SerialMon.println("Failed to set full functionality.");
        return false;
    }

    // enter PIN if necessary
    if (modem.getSimStatus() != SIM_READY) {
        if (!modem.simUnlock(GSM_PIN)) {
            Serial.println("Failed to unlock SIM");
            return false;
        }
    }

    // set network mode; 38 = LTE only
    if (!modem.setNetworkMode(38)) {
        SerialMon.println("Failed to set network mode.");
        return false;
    }

    // set preferred LTE mode; 3 = Cat-M and NB-IoT
    if (!modem.setPreferredMode(3)) {
        SerialMon.println("Failed to set preferred LTE mode.");
        return false;
    }

    SerialMon.println("\n\n\nWaiting for network...");
    if (!modem.waitForNetwork()) {
        SerialMon.println("Failed to connect to network.");
        return false;
    }

    if (modem.isNetworkConnected()) {
        SerialMon.println("Network connected.");
    }

    SerialMon.println("Connecting to APN " + String(configData.apn));
    if (!modem.gprsConnect(configData.apn, configData.gprsUser, configData.gprsPass)) {
        SerialMon.println("Failed to connect.");
        return false;
    }

    SerialMon.print("GPRS status: ");
    if (modem.isGprsConnected()) {
        SerialMon.print("connected, IP address: ");
        SerialMon.println(modem.getLocalIP());
        return true;
    } else {
        SerialMon.println("not connected");
        return false;
    }
}

// taken from https://github.com/canboat/canboat/blob/master/common/common.c, slightly modified
void getISO11783BitsFromCanId(canid_t id, unsigned int *prio, PGN *pgn, unsigned int *src, unsigned int *dst)
{
  unsigned char pf = (unsigned char) (id >> 16);
  unsigned char ps = (unsigned char) (id >> 8);
  unsigned char rdp = (unsigned char) (id >> 24) & 3; // Use R + DP bits

  if (src)
  {
    *src = (unsigned char) id >> 0;
  }
  if (prio)
  {
    *prio = (unsigned char) ((id >> 26) & 0x7);
  }

  if (pf < 240)
  {
    /* PDU1 format, the PS contains the destination address */
    if (dst)
    {
      *dst = ps;
    }
    if (pgn)
    {
      *pgn = (PGN)((rdp << 16) + (pf << 8));
    }
  }
  else
  {
    /* PDU2 format, the destination is implied global and the PGN is extended */
    if (dst)
    {
      *dst = 0xff;
    }
    if (pgn)
    {
      *pgn = (PGN)((rdp << 16) + (pf << 8) + ps);
    }
  }
}

/*
  This does the opposite from getISO11783BitsFromCanId: given n2k fields produces the extended frame CAN id
*/
canid_t getCanIdFromISO11783Bits(unsigned int prio, PGN pgn, unsigned int src, unsigned int dst)
{
  canid_t canId
      = (src & 0xff) | 0x80000000U; // src bits are the lowest ones of the CAN ID. Also set the highest bit to 1 as n2k uses
  // only extended frames (EFF bit).

  unsigned int pf = (pgn >> 8) & 0xff;

  if (pf < 240)
  { // PDU 1
    canId |= (dst & 0xff) << 8;
    canId |= (pgn << 8);
  }
  else
  { // PDU 2
    canId |= pgn << 8;
  }
  canId |= prio << 26;

  return canId;
}

int decodeMessage(struct can_frame *canMsg, PGN *pgn, float *value1, float *value2) {
    unsigned int prio, src, dst;
    getISO11783BitsFromCanId(canMsg->can_id, &prio, pgn, &src, &dst);
    uint16_t *pword;
    float *pfloat;
    switch (*pgn) {
        case heading:
            pword = (uint16_t *) (canMsg->data + 1); // start at second byte
            *value1 = toDeg(*pword / 10000.0f);
            break;
        case windSpeed:
            pword = (uint16_t *) (canMsg->data + 1); // wind speed at second byte
            *value1 = *pword / 100.0f;
            pword = (uint16_t *) (canMsg->data + 3); // wind direction at fourth byte
            *value2 = toDeg(*pword / 10000.0f);
            break;
        default: // PGN unknown
            *pgn = (PGN)(canMsg->can_id);
            pfloat = (float *)canMsg->data;
            *value1 = *pfloat;
            return -1;
    }
    return 0;
}

void sendMessage(PGN pgn, float value1, float value2) {
    struct can_frame canMsg;
    canMsg.can_id = getCanIdFromISO11783Bits(CAN_PRIO, pgn, CAN_SRC, CAN_DEST);
    canMsg.can_dlc = 8;
    for (int i = 0; i < 8; i++) {
        canMsg.data[i] = 0;
    }
    uint16_t *pword;
    int32_t *plong;
    float *pfloat;
    switch (pgn) {
        case course:
            pword = (uint16_t *) (canMsg.data + 5); // start at sixth byte
            *pword = 10000 * toRad(value1);
            break;
        case recalibrate:
            if (!value1) return; // only send message if recalibrate value is true
            break;
        case curLat: // fall-through
        case destLat:
            plong = (int32_t *) (canMsg.data);
            *plong = 10000000 * value1;
            plong = (int32_t *) (canMsg.data + 4);
            *plong = 10000000 * value2;
            break;
        case controlLevel:
            canMsg.data[0] = value1;
            break;
        case engine:
            pword = (uint16_t *) (canMsg.data + 1); // start at second byte
            *pword = value1;
            break;
        default: // PGN unknown
            pfloat = (float *)(canMsg.data);
            *pfloat = value1;
            break;
    }
    SerialMon.print("Sending CAN message: id: ");
    SerialMon.println(canMsg.can_id, HEX);
    SerialMon.print("data:");
    for (int i = 0; i < 8; i++) {
        SerialMon.print(" ");
        if (canMsg.data[i] < 16) SerialMon.print("0");
        SerialMon.print(canMsg.data[i], HEX);
    }
    SerialMon.println("");
    mcp2515.sendMessage(&canMsg);
    delay(50); // make sure messages are not sent too often
}

void forwardMessage(const char *message) {
    DynamicJsonDocument doc(DATA_SIZE);
    deserializeJson(doc, message);
    int id = doc["id"].as<int>();
    static int lastID = -1;
    if (id != lastID) { // prevent resending the same message
        for (JsonPair keyValue : doc.as<JsonObject>()) {
            if (keyValue.value().isNull()) continue;
            if (keyValue.key() == "destLat") {
                // sendMessage(destLat, 0.0f, 0.0f); // Clear waypoint list
                delay(100);
                // sendMessage(destLat, doc["destLat"], doc["destLon"]);
                continue;
            } else if (keyValue.key() == "destLon") {
                continue; // do nothing
            } else if (keyValue.key() == "route") {
                DynamicJsonDocument route(DATA_SIZE);
                deserializeJson(route, doc["route"]);
                if (route.containsKey("waypoints")) {
                    // sendMessage(destLat, 0.0f, 0.0f); // Clear waypoint list
                    delay(100);
                    JsonArray waypoints = route["waypoints"].as<JsonArray>();
                    for (JsonVariant waypoint : waypoints) {
                        // waypointList.push(std::pair <float, float>(waypoint["lat"], waypoint["lon"]));
                        // sendMessage(destLat, waypoint["latitude"].as<float>(), waypoint["longitude"].as<float>());
                    }
                }
                JsonVariant finish = route["finish"];
                // waypointList.push(std::pair <float, float>(finish["lat"], finish["lon"]));
                // if (!finish.isNull()) sendMessage(destLat, finish["latitude"].as<float>(), finish["longitude"].as<float>());
            } else {
                for (auto s : sensor) {
                    if (!strcmp(keyValue.key().c_str(), s.second.name)) {
                        // sendMessage(s.first, keyValue.value().as<float>(), 0.0);
                        break;
                    }
                }
            }
            if (keyValue.key() == "recalibrate" && keyValue.value()) {
                recalibrating = true;
            }
        }
    }
    lastID = id;
}

void updateRock7(){
    static HttpClient http(*client, configData.host, configData.port);
    if (millis() > lastSent + SEND_INTERVAL) {
        lastSent = millis();
        http.beginRequest();
        if (http.get("/api/rock7/latestOutgoing")) {
            SerialMon.println("Cannot connect to server");
        }
        else{    
            http.sendHeader("Authorization", "79f00b685636cded6b7bf6180a0a34cc4e557a44d2abcfe6fe51442e351ec9faadbe1b849af7fa7937c8850e4b2ad3a9dcae5227b77158d270400ca3");
            http.endRequest();
            if (http.responseStatusCode() != 200) {
                SerialMon.println("Cannot retrieve data from server");
            }
            else{
                String text = http.responseBody();
                SerialMon.print("Incoming message: ");
                SerialMon.println(text);
                DynamicJsonDocument doc(DATA_SIZE);
                deserializeJson(doc, text);
                int id = doc["id"].as<int>();
                static int lastID = -1;
                if (id != lastID) { // prevent resending the same message
                    for (JsonPair keyValue : doc.as<JsonObject>()) {
                        if (keyValue.value().isNull()) continue;
                        if (keyValue.key() == "destLat") {
                            desPos.first = keyValue.value();
                            waypointList = std::queue<std::pair<float, float>>();
                            continue;
                        } else if (keyValue.key() == "destLon") {
                            desPos.second = keyValue.value();
                            waypointList = std::queue<std::pair<float, float>>();
                            continue;
                        } else if (keyValue.key() == "route") {
                            DynamicJsonDocument route(DATA_SIZE);
                            deserializeJson(route, doc["route"]);
                            if (route.containsKey("waypoints")) {
                                JsonArray waypoints = route["waypoints"].as<JsonArray>();
                                for (JsonVariant waypoint : waypoints) {
                                    tempWaypointList.push(std::pair <float, float>(waypoint["lat"].as<float>(), waypoint["lon"].as<float>()));
                                SerialMon.println(waypoint["lat"].as<float>());
                                SerialMon.println(waypoint["lon"].as<float>());
                                }
                            }
                            JsonVariant finish = route["finish"];
                            tempWaypointList.push(std::pair <float, float>(finish["lat"].as<float>(), finish["lon"].as<float>()));

                        } else if (keyValue.key() == "controlLevel") {
                            controlLvl = keyValue.value();
                        } else if (keyValue.key() == "course") {
                            gewensteKoers = keyValue.value();
                        }
                        if (keyValue.key() == "recalibrate" && keyValue.value()) {
                            recalibrating = true;
                        }
                    }
                }
            }
        }
        if (recalibrating) {
            char data[] = "{\"direction\": \"outgoing\", \"reclibrate\": false}";
            http.beginRequest();
            http.post("/api/rock7s"); 
            http.sendHeader("Authorization", "79f00b685636cded6b7bf6180a0a34cc4e557a44d2abcfe6fe51442e351ec9faadbe1b849af7fa7937c8850e4b2ad3a9dcae5227b77158d270400ca3");
            http.sendHeader("Content-Type", "application/json");
            http.sendHeader("Content-Length", strlen(data));
            http.beginBody();
            http.print(data);
            http.endRequest();

            SerialMon.print("Response: ");
            int resp = http.responseStatusCode();
            SerialMon.println(resp);
            if (resp != 201) {
                SerialMon.println("Data transfer failed; resetting");
                ESP.restart();
            }
            String message = http.responseBody();
            SerialMon.println(message);
            waypointList = tempWaypointList;
            recalibrating = false;
        }
        else{
            while (!tempWaypointList.empty()){
                waypointList.push(tempWaypointList.front());
                tempWaypointList.pop();
            }
        }

        float alt, accuracy, speed;
        int vsat, usat, year, month, day, hour, min, sec;

        char timeDate[100];

        sensorData[controlLevel] = controlLvl;
        sensorData[heading] = huidigeKoers;
        sensorData[course] = gewensteKoers;
        sensorData[rudder] = roerHoek;

        if (sensorData.size()) {
            char data[DATA_SIZE] = "{\"direction\": \"incoming\"";
            // if (!wifi) {
                // String dateTime = modem.getGSMDateTime(DATE_FULL);
                // dateTime.replace('/', '-');
                // dateTime.replace(',', ' ');
                // dateTime.remove(dateTime.indexOf('+'));
                Serial.println("KAAS");
                if (modem.getGPS(&curPos.first, &curPos.second, &speed, &alt, &vsat, &usat, &accuracy,
                     &year, &month, &day, &hour, &min, &sec)) {
                    sensorData[curLat] = curPos.first;
                    sensorData[curLon] = curPos.second;
                    Serial.println("\n----------------");
                    Serial.println(sensorData[curLat]);
                    Serial.println(sensorData[curLon]);
                    Serial.println("----------------");
                    snprintf(timeDate, 100, "%02d-%02d-%d %02d:%02d:%02d", day, month, year, hour + 1, min, sec);
                    String dateTime = String(timeDate);
                    strlcat(data, ", \"dateSent\": \"", DATA_SIZE);
                    strlcat(data, dateTime.c_str(), DATA_SIZE);
                    strlcat(data, "\"", DATA_SIZE);
                }
            for (auto s : sensorData) {
                snprintf(data + strlen(data), DATA_SIZE - strlen(data), ", \"%s\": %.*f", sensor[s.first].name, sensor[s.first].precision, s.second);
            }
            if (recalibrating){
                snprintf(data + strlen(data), DATA_SIZE - strlen(data), ", \"recalibrate\": true");
            }
            else{
                snprintf(data + strlen(data), DATA_SIZE - strlen(data), ", \"recalibrate\": false");
            }
            strlcat(data, "}", DATA_SIZE);
            sensorData.clear();
            SerialMon.println("Sending data:");
            SerialMon.println(data);

            http.beginRequest();
            http.post("/api/rock7s"); 
            http.sendHeader("Authorization", "79f00b685636cded6b7bf6180a0a34cc4e557a44d2abcfe6fe51442e351ec9faadbe1b849af7fa7937c8850e4b2ad3a9dcae5227b77158d270400ca3");
            http.sendHeader("Content-Type", "application/json");
            http.sendHeader("Content-Length", strlen(data));
            http.beginBody();
            http.print(data);
            http.endRequest();

            SerialMon.print("Response: ");
            int resp = http.responseStatusCode();
            SerialMon.println(resp);
            if (resp != 201) {
                SerialMon.println("Data transfer failed; resetting");
                ESP.restart();
            }
            String message = http.responseBody();
            SerialMon.println(message);
        }
    }
    // while (mcp2515.readMessage(&canMsg) == MCP2515::ERROR_OK) {
    //     PGN pgn;
    //     float value1, value2;
    //     decodeMessage(&canMsg, &pgn, &value1, &value2);
    //     sensorData[pgn] = value1;
    //     SerialMon.print("CAN message: ");
    //     SerialMon.print(sensor[pgn].name);
    //     SerialMon.print(": ");
    //     SerialMon.println(value1);
    //     if (pgn == windSpeed) {
    //         sensorData[windDirection] = value2;
    //         SerialMon.print(sensor[windDirection].name);
    //         SerialMon.print(": ");
    //         SerialMon.println(value2);
    //     }
    // }

}

void disconnect() {
    SerialMon.println("Disconnecting.");
    client->stop();

    if (!client->connected()) {
        SerialMon.println("TCP/IP disconnected.");
    } else {
        SerialMon.println("TCP/IP disconnect: Failed.");
    }

    if (!wifi) {
        modem.gprsDisconnect();
        if (!modem.isGprsConnected()) {
            SerialMon.println("GPRS disconnected.");
        } else {
            SerialMon.println("GPRS disconnect: Failed.");
        }
        disableGPS();
        modem.poweroff();
    }
}

void count() {
  counter++;
}

float asymmetrize (int angle){
    return (((angle % 360) + 360) % 360);                        // 0 <= asym < 360
}

float symmetrize (float angle){

    return 180 - asymmetrize(180 - angle);    // -180 < sym <= 180
}

float absError(float Error){
    if (Error > 180){
        // Error = Error - 360
        Error = symmetrize(Error);
    }
    else if (Error < -180){
        // # Error = Error + 360
        Error = asymmetrize(Error);
    }
        
    return Error;
}

float LowPassFilter(float Koers_current){
            float rad = Koers_current * M_PI / 180.0;
            
            float c = cos(rad);
            float s = sin(rad);
            
            // Coëfficiënten voor de filter
            float b = 0.0591174;
            float a = 0.88176521;

            // Signaal filteren
            float y_cos = (a*y_cos_last) + (b*c) + (b*x_cos_last);
            float y_sin = (a*y_sin_last) + (b*s) + (b*x_sin_last);
            
            float Koers_filtered = std::atan2(y_sin, y_cos) * 180.0 / M_PI;

            // Waardes opslaan 
            y_cos_last = y_cos;
            x_cos_last = c;
            
            y_sin_last = y_sin;
            x_sin_last = s;
            
            return Koers_filtered;
}

float CalculateRoerHoek(float Koers_current, float Koers_desired){
            float Error = absError(Koers_desired - Koers_current);
            // print(f'Current: {Koers_current} || Desired: {Koers_desired} || Error: {Error}')
                
            // Bereken de volgende gewenste roer hoek op basis van error en PD termen 
            float P = Kp * Error;
            float D = Kd * ((Error - PreviousError)/sample_time);
            theta_r = P + D;
            
            
            // Hoek mag niet groter zijn dan 35 graden #
            if (theta_r > 35){
                theta_r = 35;
            }
            else if(theta_r < -35){
                theta_r = -35;
            }
                
            PreviousError = Error;
            return theta_r;
            
}

float get_heading() {
  float mx,my,mz;
  
  fabo_9axis.readMagnetXYZ(&mx,&my,&mz);

//   Serial.print("mx, my, mz: ");
//   Serial.print(mx);
//   Serial.print(", ");
//   Serial.print(my);
//   Serial.print(", ");
//   Serial.println(mz);

  float angle = atan2(mx - mx_corr, my - my_corr) - angle_corr;
  while (angle < 0) angle += 2*PI;
  while (angle > 2*PI) angle -= 2*PI;
//   Serial.print("heading (deg): ");
//   Serial.println(map((180.0 * angle / PI), 0, 360, 360, 0));
  return angle;
}

float create_pre_overstag_speed(float add){
    float newOffset;
    float status = 2;
    if (side == "Right"){
        Serial.println("right");
        newOffset = alteredValue - add;
    }
    
    else{
        newOffset = alteredValue + add;
    }
    return newOffset;
}

float laverenCheck(float windAngle, float targetAngle){
    // # Berekent wat de windrichting is bij de optimale koers naar de waypoint
    // # en kijkt dan of dit in de NoGO zone ligt

    float heightAngle = windAngle - targetAngle;

    if(abs( heightAngle ) > NoGOrange){
        alteredValue = 0;
        return alteredValue;
    }
    
    else{
        float status = 1;
        if(alteredValue == 0){
            if(heightAngle >= 0){
                alteredValue = NoGOrange;
                side = "Left";
            }
        }
        else{
            alteredValue = -NoGOrange;
            side = "Right";
        }
    }

    if (status == 1 && status != 2 && abs( heightAngle ) > NoGOrange - 20){
        return create_pre_overstag_speed(15);
    }
    
    return alteredValue;
}

float CourseBetweenWaypoints(std::pair<float, float> pointA, std::pair<float, float> pointB){
        // SOURCE: https://gist.github.com/jeromer/2005586
        
        float lat1 = toRad(pointA.first);
        float lat2 = toRad(pointB.first);

        float diffLong = toRad(pointB.second - pointA.second);

        float x = sin(diffLong) * cos(lat2);
        float y = cos(lat1) * sin(lat2) - (sin(lat1) * cos(lat2) * cos(diffLong));

        float initial_bearing = atan2(x, y);
        float Koers_desired_waypoint = toDeg(initial_bearing) * -1;

        return -Koers_desired_waypoint;
}
    
float DistanceBetweenWaypoints(std::pair<float, float> pointA, std::pair<float, float> pointB){
    // SOURCE: https://stackoverflow.com/a/4913653
    
    // convert decimal degrees to radians
    float lat1 = toRad(pointA.first);
    float lat2 = toRad(pointB.first);
    
    float lon1 = toRad(pointA.second);
    float lon2 = toRad(pointB.second);

    // haversine formula 
    float dlon = lon2 - lon1;
    float dlat = lat2 - lat1;
    float a = pow(sin(dlat/2), 2) + cos(lat1) * cos(lat2) * pow(sin(dlon/2),2);
    float c = 2 * asin(sqrt(a));
    float r = 6371000; // Radius of earth in meters. Determines return value units.
    
    return c * r;
}

void addWayPoint(std::pair<float, float> waypoint){
        waypointList.push(waypoint);
}

std::pair<float, float> NextWaypoint(){
    std::pair <float, float> kaas(51.91740867344284, 4.484817211733659);
    if (waypointList.size() == 0)
        return kaas;
    std::pair<float, float> temp = waypointList.front();
    waypointList.pop();    
    return temp;
}

void ClearWaypointList(){
    waypointList = std::queue<std::pair<float, float>> ();
}

void i2cScanner(){
  byte error, address;
  int nDevices;
  Serial.println("Scanning...");
  nDevices = 0;
  for(address = 1; address < 127; address++ ) {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();
    if (error == 0) {
      Serial.print("I2C device found at address 0x");
      if (address<16) {
        Serial.print("0");
      }
      Serial.println(address,HEX);
      nDevices++;
    }
    else if (error==4) {
      Serial.print("Unknow error at address 0x");
      if (address<16) {
        Serial.print("0");
      }
      Serial.println(address,HEX);
    }    
  }
  if (nDevices == 0) {
    Serial.println("No I2C devices found\n");
  }
  else {
    Serial.println("done\n");
  }
  delay(5000);  
}

void readCalib() {
  EEPROM.get(0, mx_corr);
  EEPROM.get(4, my_corr);
  EEPROM.get(8, angle_corr); 
}

void writeCalib() {
  EEPROM.put(0, mx_corr);
  EEPROM.put(4, my_corr);
  EEPROM.put(8, angle_corr); 
}

void calibrate() {
  float mx,my,mz;
  
  Serial.println("Calibrating; please rotate sensor for 30 s");
  mx_corr = 0;
  my_corr = 0;
  angle_corr = 0;
  long counter = 0;
  long startTime = millis();
  long promptTime = startTime + 1000;
  while (millis() < startTime + 30000) {
    fabo_9axis.readMagnetXYZ(&mx,&my,&mz);
    mx_corr += mx;
    my_corr += my;
    counter++;
    if (millis() > promptTime) {
      Serial.println((millis() - startTime) / 1000);
      promptTime += 1000;
    }
    delay(100);
  }
  mx_corr /= counter;
  my_corr /= counter;
  Serial.println("Calibration done");
  Serial.print("mx_corr = ");
  Serial.println(mx_corr);
  Serial.print("my_corr = ");
  Serial.println(my_corr);
  Serial.println("Please point sensor due north in 10 s");
  for(int i = 10; i >= 0; i--) {
    Serial.println(i);
    delay(1000);
  }
  angle_corr = get_heading();
  Serial.print("angle_corr = ");
  Serial.println(angle_corr);
  writeCalib();
}

void initMPU(){
    Serial.println("configuring MPU9250");

    if (fabo_9axis.begin()) {
        Serial.println("MPU9250 initialised");
    } else {
        Serial.println("MPU9250 error");
        MPU_OK = false;
    }
}

void initCAN(){
    mcp2515.reset();
    mcp2515.setBitrate(CAN_BITRATE);
    mcp2515.setNormalMode();
}

void initESPConfig(){
    EEPROM.begin(EEPROM_SIZE);
    if (EEPROM.read(0) == EEPROM_OK) { // check if set before
        SerialMon.print("Enter any input to set up network");
        for (int i = 0; i < 5; i++) {
            SerialMon.print('.');
            if (SerialMon.available()) {
                while (SerialMon.available()) { // clear buffer
                    SerialMon.read();
                    delay(1);
                }
                SerialMon.print('\n');
                config(true);
                break;
            }
            delay(1000);
        }
    } else { // go straight to config mode
        config(false);
    }
}

void initWifiGPRS(){
    pinMode(PIN_LED, OUTPUT);
    Ticker blinker;
    blinker.attach(0.1, blink); // start blinking

    EEPROM.get(1, configData);

    if (connectWifi()) {
        wifi = true;
        // wifiClient.setCACert(rootCA);
        client = &wifiClient;
    } else if (connectGprs()) {
        client = &gprsClient;
    } else {
        blinker.detach(); // stop blinking
        digitalWrite(PIN_LED, HIGH); // turn off LED (anode of LED is wired to Vcc, so setting to HIGH turns LED off)
        ESP.restart();
    }

    SerialMon.println("Connected.");
    blinker.detach(); // stop blinking
    digitalWrite(PIN_LED, LOW); // turn on LED (anode of LED is wired to Vcc, so setting to LOW turns LED on)


    SerialMon.println("Transmitting data. Enter any input to disconnect.");
}

void bestuurBoot(){
    if (millis() > last_time + 1000) {
        last_time = millis();
        if (MPU_OK) {
            float heading  = map((180.0 * get_heading() / PI), 0, 360, 360, 0);
            if (heading > 180) heading = map(heading, 180, 360, -180, 0);
            huidigeKoers =  heading;
        }
        // huidige koers 1 tm 180 is normaal, 180 tm 360 = -180 tm 0. dus 350 == -10
        float alt, accuracy, speed;
        int vsat, usat, year, month, day, hour, min, sec;

        // if (modem.getGPS(&curPos.first, &curPos.second, &speed, &alt, &vsat, &usat, &accuracy, &year, &month, &day, &hour, &min, &sec)) {
        //     printf("\n----------------- \n");
        //     printf("UPDATE: curPos: %f, %f", curPos.first, curPos.second);
        //     printf("\n----------------- \n");
        //                                     }

        if (!waypointList.empty()) desPos = waypointList.front();
        printf("\n----------------- \n");
        printf("Huidigekoers: %f\n", huidigeKoers);
        // roerHoek = CalculateRoerHoek(huidigeKoers, gewensteKoers);
        printf("gewenstekoers: %f\n", gewensteKoers);
        printf("curPos: %f, %f - desPos: %f, %f \n", curPos.first, curPos.second, desPos.first, desPos.second);
        gewensteKoers = CourseBetweenWaypoints(curPos, desPos);
        printf("course: %f\n", CourseBetweenWaypoints(curPos, desPos));
        roerHoek = CalculateRoerHoek(huidigeKoers, gewensteKoers);
        printf("Distance between waypoint: %f\n", DistanceBetweenWaypoints(curPos, desPos));
        if (roerHoek < 0){
            pos = map((roerHoek), 0, -35, 90, 0);
        }
        else pos = map((roerHoek), 0, 35, 90, 180);
        printf("Servo angle: %f\n ----------------- \n", pos);
        if (DistanceBetweenWaypoints(curPos, desPos) <= 5 && !waypointList.empty()){
            
            waypointList.pop();
        }
    }
    servo.write(pos);
}

void setup() {
    SerialMon.begin(115200);
    SerialMon.setTimeout(-1);
    SerialMon.println('\n'); // start with a blank line in the serial monitor

    Wire.begin();
    servo.attach(32); // attach servo pin to servo object
    initMPU();

    initESPConfig();
    initWifiGPRS();
    enableGPS(false);
    initCAN();

    // calibrate();
    // readCalib();

    last_time, lastSent = millis();

    while (SerialMon.available()) { // clear buffer
        SerialMon.read();
        delay(1);
    }
    

    // waypointList.push(std::pair <float, float>(51.89826965538147, 4.418014723834804));
    // waypointList.push(std::pair <float, float>(51.898115658117305, 4.416196458513382));
    // waypointList.push(std::pair <float, float>(51.89744741387546, 4.416339067551475));
    // waypointList.push(std::pair <float, float>(51.89760416341354, 4.418206354725494));
}

void loop() {
    updateRock7();

    bestuurBoot();

    if (SerialMon.available()) {
        disconnect();
        digitalWrite(PIN_LED, HIGH); // turn off LED (anode of LED is wired to Vcc, so setting to HIGH turns LED off)
        SerialMon.println("Enter 'reset' to reset.");
        while (true) {
            String resp = SerialMon.readStringUntil('\n');
            if (resp.startsWith("reset")) {
                SerialMon.println("Restarting");
                ESP.restart();
            }
        } 
    }
    delay(1);
}