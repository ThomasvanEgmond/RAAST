CAN to WiFi/4G bridge for LilyGO-T-SIM7000G (ESP32) and MCP2515 module  
Wouter Bergmann Tiest  
23 March 2022

Required libraries:
- TinyGSM
- ArduinoHttpClient
- autowp-arduino-mcp2515
- ArduinoJSON

Enter any input within 5 seconds after start-up to enter
config mode. Enter NULL as password to connect to unprotected
WiFi network. Expects a webserver running on host:port.
Config data is stored in flash memory (using EEPROM library).

First tries to connect using WiFi. If this fails, tries GPRS.  
LED blinking: trying to establish connection  
LED fixed: connection established  

Connections for MCP2515 module:  
SCK: pin 18  
MISO: pin 19  
MOSI: pin 23  
CS: pin 5

Note: although the MCP2515 chip can run on 3.3V, the TJA1050
transceiver chip cannot and requires 5V, so Vcc on the MCP2515 
module needs to be connected to Vin_5V on the LilyGO board.
