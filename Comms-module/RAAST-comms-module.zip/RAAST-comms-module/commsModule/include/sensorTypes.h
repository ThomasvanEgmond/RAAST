#include <string.h>
#include <map>
#define NAME_SIZE 14

struct sensorType {
    char name[NAME_SIZE];
    int precision;
    sensorType(const char *name_, int precision_) {
        strncpy(name, name_, NAME_SIZE);
        precision = precision_;
    }
    sensorType() {}
};

enum PGN {
    curLat = 129025,
    curLon,
    destLat = 61445,
    destLon,
    seaTemp = 1,
    acidity,
    salinity,
    maxHeel,
    rudder,
    maxRudder,
    sail,
    course = 127237,
    heading = 127250,
    windSpeed = 130306,
    windDirection,
    speed,
    maxSpeed,
    controlLevel = 61444,
    recalibrate = 61443,
    pid_kp = 61440,
    pid_ki = 61441,
    pid_kd = 61442,
    engine = 127488
};

// PGN from enum above; sensorType: name for transceiver, number of decimal
// places of value
std::map<PGN, sensorType> sensor = {
    { curLat, sensorType("curLat", 6) },
    { curLon, sensorType("curLon", 6) },
    { destLat, sensorType("destLat", 6) },
    { destLon, sensorType("destLon", 6) },
    { seaTemp, sensorType("seaTemp", 2) },
    { acidity, sensorType("acidity", 2) },
    { salinity, sensorType("salinity", 2) },
    { maxHeel, sensorType("maxHeel", 0) },
    { rudder, sensorType("rudder", 0) },
    { maxRudder, sensorType("maxRudder", 0) },
    { sail, sensorType("sail", 0) },
    { course, sensorType("course", 0) },
    { heading, sensorType("heading", 0) },
    { windDirection, sensorType("windDirection", 0) },
    { windSpeed, sensorType("windSpeed", 2) },
    { speed, sensorType("speed", 2) },
    { maxSpeed, sensorType("maxSpeed", 2) },
    { controlLevel, sensorType("controlLevel", 0) },
    { recalibrate, sensorType("recalibrate", 0) },
    { pid_kp, sensorType("pid_kp", 6) },
    { pid_ki, sensorType("pid_ki", 6) },
    { pid_kd, sensorType("pid_kd", 6) },
    { engine, sensorType("engine", 0) }
};