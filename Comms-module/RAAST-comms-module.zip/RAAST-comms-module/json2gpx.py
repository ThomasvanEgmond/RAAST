#!/usr/local/bin/python3

# Retrieve file with
# curl -odata.json https://transceiver.hr.nl/api/rock7s -H 'accept: application/json' -H 'Authorization: 79f00b685636cded6b7bf6180a0a34cc4e557a44d2abcfe6fe51442e351ec9faadbe1b849af7fa7937c8850e4b2ad3a9dcae5227b77158d270400ca3'

from lxml import etree
import gpx # https://github.com/sgraaf/PyGPX
import json
import sys

def parse(entry):
    try:
        if entry["curLat"] is None or entry["curLon"] is None or entry["dateSent"] is None:
            return None
        e = etree.Element("wpt", lat = str(entry["curLat"]), lon = str(entry["curLon"]))
        etree.SubElement(e, "time").text = entry["dateSent"].replace(" ", "T")
    except:
        return None
    return gpx.Waypoint(e)

if len(sys.argv) == 3:
    input = sys.argv[1]
    output = sys.argv[2]
else:
    print(f"Usage: {sys.argv[0]} input.json output.gpx")
    sys.exit()
try:
    file = open(input)
    json_data = json.load(file)
except:
    print(f"Error reading file {input}")
    sys.exit()
file.close()
wps = [parse(entry) for entry in json_data]
while None in wps:
    wps.remove(None)
print(f"Found {len(wps)} track points")

my_track = gpx.Track()
my_track.name = "RAAST"
my_track.segments = [wps]
my_gpx = gpx.GPX()
my_gpx.tracks = [my_track]
my_gpx.to_file(output)
