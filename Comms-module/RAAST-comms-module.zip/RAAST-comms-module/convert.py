#!/usr/local/bin/python3

from lxml import etree
import gpx # https://github.com/sgraaf/PyGPX
import json
import sys

def parse(line):
    fields = line.split(" -> ")
    if fields[1].startswith("Data received from boat: "):
        json_string = fields[1].split(": ")[1]
        try:
            json_data = json.loads(json_string)
        except:
            pass
        else:
            if "curLat" in json_data and "curLon" in json_data and "dateSent" in json_data:
                e = etree.Element("wpt", lat = str(json_data["curLat"]), lon = str(json_data["curLon"]))
                etree.SubElement(e, "time").text = json_data["dateSent"].replace(" ", "T")
                return gpx.Waypoint(e)

if len(sys.argv) == 3:
    input = sys.argv[1]
    output = sys.argv[2]
else:
    print(f"Usage: {sys.argv[0]} input.log output.gpx")
    sys.exit()
file = open(input)
data = list(file.read().splitlines())
file.close()
wps = [parse(line) for line in data]
while None in wps:
    wps.remove(None)
print(f"Found {len(wps)} track points")

my_track = gpx.Track()
my_track.name = "RAAST"
my_track.segments = [wps]
my_gpx = gpx.GPX()
my_gpx.tracks = [my_track]
my_gpx.to_file(output)
