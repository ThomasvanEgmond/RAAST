#!/usr/local/bin/python3

import gpx # https://github.com/sgraaf/PyGPX
import json
import sys

if len(sys.argv) == 3:
    input = sys.argv[1]
    output = sys.argv[2]
else:
    print(f"Usage: {sys.argv[0]} input.gpx output.json")
    sys.exit()

try:
    my_gpx = gpx.GPX.from_file(input)
except:
    print(f"Error reading file {input}")
    sys.exit()
route = my_gpx.routes[0]
print(f"Found {len(route.points)} route points")
waypoints = {"waypoints": [{"latitude": wp.lat, "longitude": wp.lon} for wp in route.points[:-1]]}
finish = route.points[-1]
waypoints["finish"] = {"latitude": finish.lat, "longitude": finish.lon}
file = open(output, "w")
json.dump(waypoints, file)
file.close()