from machine import I2C, Pin
from mpu9250 import MPU9250
from ak8963 import AK8963
import math
import time

i2c = I2C(scl=Pin(15), sda=Pin(14), id=1)

dummy = MPU9250(i2c) # this opens the bybass to access to the AK8963
ak8963 = AK8963(i2c, offset=(27.07237, 9.174025, 46.2211),
                     scale=(1.117278, 1.733509, 0.6544061))

#offset, scale = ak8963.calibrate(count=256, delay=200)
#print(offset)
#print(scale)

s = MPU9250(i2c, ak8963=ak8963)

while True:
    x =  s.magnetic[0]
    y =  s.magnetic[1]
    
    #print(f'x: {x} y: {y}')
    
    heading = (180 * math.atan2(y,x)/math.pi)
    
    print(heading)
    time.sleep(0.1)