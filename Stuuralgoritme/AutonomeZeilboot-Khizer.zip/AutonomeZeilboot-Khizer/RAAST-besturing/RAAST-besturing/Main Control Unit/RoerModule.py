import machine
from time import sleep
import math

# #constanten actuator
# stroke_totaal=130
# s0=265.425
# 
# #constanten afmetingen constructie
# a      = -62.875
# b      = 308.925
# straal = 70.2

Dca = 0.016    # 
Dac = 0.022   #
Ls  = 0.13    # Max slag cilinder

# Max en minimale hoeken van het roer
maxAngle = 69
minAngle = -69

# Verhouding tussen ADC en slag van de cilinder
ratio = 65536/(Ls*1000)

# Eindstops voor actuator
minADCValue = 10000
maxADCValue = 57000

class Receiver:
    def __init__(self, name, pin, min, max):
        self.name        = name       # Naming the pin
        self.pin         = machine.Pin(pin, machine.Pin.IN) # Defining the pin
        self.min         = min        # Min value of channel
        self.max         = max        # Max value of channel
        self.value       = 0          # Default value
        self.edge        = 1          # 1 for rising edge 0 for falling edge
        self.wait        = 30000      # Default max wait time for previous pulse to end
        self.adc_gewenst = 0

        self.regelaar_counter    = 0
        self.transmitter_counter = 0
        self.Regelaar_enable     = False
        self.Transmitter_enable  = False
        
    def map(self):
        return (self.value - self.min) * (maxAngle - minAngle) / (self.max - self.min) + minAngle;
        
    def read(self):
        sleep(0.05)
        self.value = machine.time_pulse_us(self.pin, self.edge, self.wait)
        #print(f' RC STICK WAARDE : {machine.time_pulse_us(self.pin, self.edge, self.wait)}')
        self.value = int(self.map())
        #print(f' RC MAP: {self.value}')
        #self.calculateADC()
        return self.value

    def calculateADC(self, hoek):
        #w=(self.value-(2063))/1662*90-45
        w = hoek
        if (w > 35):
            w = 35
        elif (w <= -35):
            w = -35
            
        rad = math.radians(w)
        s   = math.sin(rad)
        h   = ((Dca/2)+(Dac/2)+0.001) ** 2 
        sl  = (Ls/2) **2
        sqr = math.sqrt(h+sl)

        m = (s*sqr) + Ls/2
        mm = m*1000
        self.adc_gewenst = mm * ratio

    def ReadTransmitterState(self, Switch):
        if Switch > 15 or -200 < Switch < -15:
            if Switch > 15:
                self.regelaar_counter += 1
            
            elif -100 < Switch < -15:
                self.transmitter_counter += 1
            
            if (self.regelaar_counter + self.transmitter_counter >= 4):
                if self.regelaar_counter > self.transmitter_counter:
                    self.Regelaar_enable      = True
                    self.Transmitter_enable   = False
                    
                elif self.transmitter_counter > self.regelaar_counter:
                    self.Regelaar_enable      = False
                    self.Transmitter_enable   = True
                    
                self.regelaar_counter    = 0
                self.transmitter_counter = 0

        elif Switch < -130:
            self.Regelaar_enable    = False
            self.Transmitter_enable = False
            
        return self.Regelaar_enable, self.Transmitter_enable

class Actuator:
    def __init__(self, extPin, retPin, adcPin):
        self.extPin   = machine.Pin(extPin, machine.Pin.OUT) 
        self.retPin   = machine.Pin(retPin, machine.Pin.OUT) 
        self.adcPin   = machine.ADC(adcPin)
        self.adcValue = 0
    
    def read_adc(self):
        self.adcValue = self.adcPin.read_u16()
        #print (f'ADC value: {self.adcValue}')

    def gotoreceiver(self, receiver):
        if receiver.adc_gewenst < minADCValue or receiver.adc_gewenst > maxADCValue:
            # incorrect values
            return
        
        self.read_adc()

        if (self.adcValue - 1700) <= receiver.adc_gewenst <= (self.adcValue + 1700):
            self.extPin.value(0)
            self.retPin.value(0)
            #print("Actuator in position")
            
        elif receiver.adc_gewenst > self.adcValue and self.adcValue > minADCValue:
            self.extPin.value(1)
            self.retPin.value(0)
            #print("Actuator extending")
            
        elif receiver.adc_gewenst < self.adcValue and self.adcValue < maxADCValue:
            self.extPin.value(0)
            self.retPin.value(1)
            #print("Actuator retracting") 
