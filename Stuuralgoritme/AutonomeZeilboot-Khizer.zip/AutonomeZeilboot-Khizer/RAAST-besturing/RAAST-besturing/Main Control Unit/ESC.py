from machine import PWM, Pin
import time

# ESC heeft een PWM signaal nodig om de motor aan te sturen.
# Stop        = 1500 μs
# Max forward = 1900 μs
# Max reverse = 1100 μs

class T200ESC:
    def __init__(self, pin, freq, lower, upper):
        self.pin   = pin         # Pin voor het sturen van PWM signaal naar ESC
        self.freq  = freq        # Frequentie van PWM
        self.lower = lower       # Minimale waarde uit de RC kanaal 
        self.upper = upper       # Maximale waarde uit de RC kanaal
        self.dutycycle = 0

        
        self.pwm = PWM(Pin(pin))
        self.pwm.freq(freq)
        
    def ESCinit(self):
        self.pwm.duty_ns(1500*1000)
        time.sleep(2)
        
    
    def RCnaarESC(self, RC):
        if RC > 0:
            ratio = self.upper/400
        elif RC < 0:
            ratio = -1*self.lower/400
        elif RC == 0:
            ratio = 1
        self.dutycycle = int(1500 + (RC/ratio))
        
        #print(f'RC: {RC} || Cycle:{self.dutycycle}')
        
        if (self.dutycycle < 1100):
            self.dutycycle = 1100
        elif (self.dutycycle > 1900):
            self.dutycycle = 1900
            
        if -10 <= RC <= 10:
            self.dutycycle = 1500
    
        #print(f'Cycle TWO:{self.dutycycle}')
        
        if 1100 <= self.dutycycle <= 1900:
            self.pwm.duty_ns(self.dutycycle*1000)
    
    def WALnaarESC(self, val):
        self.dutycycle = 1500 + (400*val)
        
        if 1100 <= self.dutycycle <= 1900:
            self.pwm.duty_ns(self.dutycycle*1000)
        
            
