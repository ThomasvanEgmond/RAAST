from machine import Pin, I2C
# from mpu9250 import MPU9250
# from ak8963 import AK8963
import math
import time

def ShortestPath(Error):
    if Error > 180:
        Error = Error - 360
       
    elif Error < -180:
        Error = Error + 360
        
    return Error

class KoersRegeling:
    def __init__(self, Kp, Ki, Kd, sample_time):
        self.Kp            = Kp             # Proportionele term
        self.Ki            = Ki             # Integrale term
        self.Kd            = Kd             # Differentiele term
        self.sample_time   = sample_time    # Na hoeveel tijd de sensor wordt uitgelezen (in seconde)
        
        self.PreviousError = 0              # Variable om de vorige error op te slaan voor differentieren en integreren
        self.theta_r       = 0              # Standaard roer hoek van 0 graden
        
        # Variabelen om waardes op te slaan voor low pass filter
        self.y_cos_last = 0 
        self.x_cos_last = 0
        
        self.y_sin_last = 0
        self.x_sin_last = 0
        
    def CalculateRoerHoek(self, Koers_current, Koers_desired):
        Error = Koers_desired - Koers_current
        Error = ShortestPath(Error)
        #print(f'Current: {Koers_current} || Desired: {Koers_desired} || Error: {Error}')
            
        # Bereken de volgende gewenste roer hoek op basis van error en PD termen 
        P = self.Kp * Error
        D = self.Kd * ((Error - self.PreviousError)/self.sample_time)
        self.theta_r = P + D
        
        
        # Hoek mag niet groter zijn dan 35 graden #
        if self.theta_r > 35:
            self.theta_r = 35
            
        elif self.theta_r < -35:
            self.theta_r = -35
            
        self.PreviousError = Error
        return self.theta_r

    # Functie voor het filteren van signalen boven 0.2 Hz
    def LowPassFilter(self, Koers_current):
        rad = math.radians(Koers_current)
        
        c = math.cos(rad)
        s = math.sin(rad)
        
        # Coëfficiënten voor de filter
        b = 0.0591174
        a = 0.88176521

        # Signaal filteren
        y_cos = (a*self.y_cos_last) + (b*c) + (b*self.x_cos_last)
        y_sin = (a*self.y_sin_last) + (b*s) + (b*self.x_sin_last)
        
        Koers_filtered = math.degrees(math.atan2(y_sin, y_cos))

        # Waardes opslaan 
        self.y_cos_last = y_cos
        self.x_cos_last = c
        
        self.y_sin_last = y_sin
        self.x_sin_last = s
        
        return Koers_filtered
    
class Route:
    def __init__(self, NoGOrange):
        self.NoGOrange  = NoGOrange       # Gebied tegen de wind in dat niet gezeild kan worden (in graden)                               
        self.CourseNoGO = False           # Of de optimale koers koers in dat gebied zit        (Ja/Nee)
        self.SideChosen = False           # Of er een kant gekozen                              (Ja/Nee)
        self.WindDirAtDesired = 0         # Winddirectie bij een gewenste koers                 (in graden)
        self.KoersAtStart     = 0         # Dichtst mogelijke koers bij de optimale koers die gekozen wordt aan het begin 
        self.WaypointList = []
    
    def CourseBetweenWaypoints(self, pointA, pointB):
        # SOURCE: https://gist.github.com/jeromer/2005586
        
        lat1 = math.radians(pointA[0])
        lat2 = math.radians(pointB[0])

        diffLong = math.radians(pointB[1] - pointA[1])

        x = math.sin(diffLong) * math.cos(lat2)
        y = math.cos(lat1) * math.sin(lat2) - (math.sin(lat1)
                * math.cos(lat2) * math.cos(diffLong))

        initial_bearing = math.atan2(x, y)
        Koers_desired_waypoint = math.degrees(initial_bearing) * -1

        return Koers_desired_waypoint
    
    def DistanceBetweenWaypoints(self, pointA, pointB):
        # SOURCE: https://stackoverflow.com/a/4913653
        
        # convert decimal degrees to radians
        lat1 = math.radians(pointA[0])
        lat2 = math.radians(pointB[0])
        
        lon1 = math.radians(pointA[1])
        lon2 = math.radians(pointB[1])

        # haversine formula 
        dlon = lon2 - lon1 
        dlat = lat2 - lat1 
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a)) 
        r = 6371000 # Radius of earth in meters. Determines return value units.
        
        return c * r
    
    def checkNoGO(self, windDir, Koers_current, Koers_desired_waypoint):
        # Berekent wat de windrichten is bij de optimale koers naar de waypoint
        # en kijkt dan of dit in de NoGO zone ligt
        Error = Koers_desired_waypoint - Koers_current
        Error = ShortestPath(Error)
        
        self.WindDirAtDesired = windDir - Error
        
        if -1*self.NoGOrange/2 < self.WindDirAtDesired < self.NoGOrange/2:
            self.CourseNoGO = True
        else:
            self.CourseNoGO = False
        
        return self.CourseNoGO
    
    def CalculateSailableCourse(self, Koers_current, Koers_desired_waypoint, windDir):
        # Als [CourseNoGO = True] en er is een zijde aan de wind gekozen
        if self.SideChosen == True:
            # Kijk eerst of de huidige koers in de buurt is van de gekozen koers aan het begin
            # Zo ja, pas gewenste koers aan op basis van de windrichting om zo scherp aan de wind te varen
            # Zo nee, blijf naar de gekozen koers varen.
            if self.KoersAtStart - 30 < Koers_current < self.KoersAtStart + 30:
                if windDir > 0:
                    Error = self.NoGOrange/2 - windDir
                elif windDir <= 0:
                    Error = -1*self.NoGOrange/2 - windDir
                else:
                    Error = 0
                
                Koers_desired = Koers_current - Error
                Koers_desired = ShortestPath(Koers_desired)
                
            else:
                Koers_desired = self.KoersAtStart
                
        # Als [CourseNoGO = True] en er is nog geen zijde aan de wind gekozen
        # Kiest de scherpst mogelijke vaarbare koers die het dichtst bij de optimale koers licht  
        elif self.SideChosen == False:
            if self.WindDirAtDesired > 0:
                Error = self.NoGOrange/2 - self.WindDirAtDesired
            elif self.WindDirAtDesired <= 0:
                Error = -1*self.NoGOrange/2 - self.WindDirAtDesired
            else:
                Error = 0
            
            Koers_desired = Koers_desired_waypoint - Error
            Koers_desired = ShortestPath(Koers_desired)
            
            self.KoersAtStart = Koers_desired
            self.SideChosen = True
        
        return Koers_desired
    
    def AddWaypoint(self, waypoint):
        self.WaypointList.append(waypoint)

    def NextWaypoint(self):
        if len(self.WaypointList) == 0:
            return None
        return self.WaypointList.pop(0)
    
    def ClearWaypointList(self):
        self.WaypointList = []            
        