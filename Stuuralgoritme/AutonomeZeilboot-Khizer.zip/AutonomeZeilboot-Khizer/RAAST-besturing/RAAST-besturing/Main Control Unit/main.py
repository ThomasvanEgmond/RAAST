import Regeling    # Module voor de regeling
import RoerModule  # Module met classes voor de Receiver en Actuator
import ESC         # Module om snelheid van de motor te besturen
import CAN         # Module voor het lezen en decoderen van de CAN berichten

from machine import Pin, I2C
from ina219 import INA219
import time
import math
import struct

# Objecten initialiseren
actuator   = RoerModule.Actuator(20, 21, 28)
RoerStick  = RoerModule.Receiver("ch1", 18, 1132, 1919)     # Linker horizontale stick, bestuurt de roer hoek in RC mode
Throttle   = RoerModule.Receiver("ch2", 16, 1132, 1919)     # Linker verticale stick, bestuurt de throttle van motor
SwitchKnob = RoerModule.Receiver("ch3", 17, 1132, 1919)     # Draai knop VR(A) op transmitter voor schakelen tussen RC mode en regelaar. Links is RC, rechts is regeling
ESC        = ESC.T200ESC(1, 100, -49, 66)                   # ESC die op basis van throttle de motorsnelheid bestuurt
Koers      = Regeling.KoersRegeling(-0.5, 0, -0.5, 1)       # Koer regeling, berekent roerhoek bij een gewenste koers
Route      = Regeling.Route(90)                             # Stuuralgoritme, bepaald benodigde koers om een waypoint te bereiken

# CANbus,  ESC en stroomsensor initialiseren
can = CAN.init()
ESC.ESCinit()

I2C_INTERFACE_NO  = 2
SHUNT_OHMS        = 0.1
MAX_EXPECTED_AMPS = 0.001

'''
ina = INA219(SHUNT_OHMS, I2C(id=0, sda=Pin(0), scl=Pin(1)), MAX_EXPECTED_AMPS)
ina.configure(ina.RANGE_32V)
'''

# Counter for logfiles
with open('counter.txt','r') as count:
    for line in count:
        n = line.rstrip('\n')
count.close

count = open("counter.txt", "w")
count.write(str(int(n)+1) + "\n")
count.close

ControlMode  = 0
current_lat  = 0
current_lon  = 0
dest_lat     = 0
dest_lon     = 0
Koers_desired          = 0
Koers_desired_waypoint = 0
Koers_current          = 0

Regelaar_enable = False
Transmitter_enable = False

def MapTo180(angle):
    if angle > 180:
        angle = 360 - angle
    elif 0 < angle < 180:
        angle = angle * -1
    return angle

try:
    ticks = time.ticks_ms()
    while True:
        if time.ticks_ms() > ticks + 200:
            ticks = time.ticks_ms()
            
            Switch = SwitchKnob.read()
            #print(f'SWITCH: {Switch}')
            if Switch > -130:
                thrValue = Throttle.read()
                #print(f'THROTTLE: {thrValue}')
                ESC.RCnaarESC(thrValue)
            
            Regelaar_enable, Transmitter_enable = SwitchKnob.ReadTransmitterState(Switch)
        
            if Transmitter_enable:
                hoek = RoerStick.read()
                RoerStick.calculateADC(hoek)
                #print(f'Hoek: {hoek}')
                actuator.gotoreceiver(RoerStick)
                #print("RC transmitter ENABLE")
                
            elif ControlMode == 0 and not Regelaar_enable:
                # Zet roer en motor in neutrale stand
                RoerStick.calculateADC(0)
                actuator.gotoreceiver(RoerStick)
                ESC.RCnaarESC(0)
                #print("RC transmitter is OFF")
            
        error, iframe = CAN.CANRead(can)
        if error == 0:
            #print(f'ID: {iframe.can_id}')
            pgn = CAN.CANDecode(iframe)
            #print(f' PGN: {pgn}')
            if pgn == 127250:
                Koers_current = ((iframe.data[1] + iframe.data[2]*256)/10000)*(180/3.14)
                Koers_current = MapTo180(Koers_current)
                #print(f'Koers: {Koers_current}')

                if Regelaar_enable or (not Transmitter_enable and (ControlMode == 1 or ControlMode == 2)):
                    # Als sample time voorbij is bereken nieuwe roer stand
                    # Sensor lezing filteren, gewenste roerstand berekenen en actuator aansturen
                    Koers_filtered = Koers.LowPassFilter(Koers_current)
                    Roer_desired  = Koers.CalculateRoerHoek(Koers_filtered, Koers_desired)
                    RoerStick.calculateADC(Roer_desired)
                    actuator.gotoreceiver(RoerStick)
                    
                    #print(f'Current: {Koers_current}/{Koers_filtered} || Desired: {Koers_desired} || Error: {Koers_desired - Koers_filtered} || Roer: {Roer_desired}')

                    # Huidige roerhoek berekenen
                    adc = actuator.adcValue/1000
                    Roer_current = (0.00037*adc*adc*adc) - (0.03671*adc*adc) + (2.57068*adc) - 58.06227
                    
                    # Data opslaan in text bestand
                    log_txt = open(f"log/log_{n}.txt", "a")
                    d = (str(int(Koers_current)),
                         str(int(Koers_filtered)),
                         str(int(Koers_desired)),
                         str(int(Roer_current)),
                         str(Roer_desired),
                         'NA', #str(ina.current()),
                         str(ESC.dutycycle),
                         str(current_lat),
                         str(current_lon),
                         str(ControlMode)
                         )
                    dline = f"{d[0]},{d[1]},{d[2]},{d[3]},{d[4]},{d[5]},{d[6]},{d[7]},{d[8]},{d[9]}\n"
                    
                    log_txt.write(dline)
                    log_txt.flush()
                    log_txt.close()

            elif pgn == 127237:
                Koers_desired = ((iframe.data[5] + iframe.data[6]*256)/10000)*(180/3.14)
                Koers_desired = MapTo180(Koers_desired)
                    
                print(f'Koers desired: {Koers_desired}')

                dest_lat, dest_lon = (0, 0) # reset destination position to maintain set course

            elif pgn == 130306:
                WindDir = ((iframe.data[3] + iframe.data[4]*256)/10000)*(180/3.14) 
                WindDir = MapTo180(WindDir)
                
                WindSpeed = (iframe.data[1] + iframe.data[2]*256)/100
                
                #print(f'WindDir: {WindDir}')
                #print(f'WindSpeed : {WindSpeed }')
                
            elif pgn == 129025:
                current_lat = struct.unpack('l', iframe.data[:4])[0]/10000000
                current_lon = struct.unpack('l', iframe.data[4:8])[0]/10000000
                print(f' Current pos: {current_lat} , {current_lon}')
                
                if dest_lat != 0:
                    p1 = current_lat, current_lon
                    p2 = dest_lat, dest_lon
                    
                    Koers_desired = Route.CourseBetweenWaypoints(p1, p2)
                    distance_from_waypoint = Route.DistanceBetweenWaypoints(p1, p2)
                    print(f'Waypoint Koers desired: {Koers_desired}')
                    print(f'Waypoint distance: {distance_from_waypoint}')
                    if distance_from_waypoint < 10: # waypoint reached
                        next_waypoint = Route.NextWaypoint()
                        if next_waypoint != None:
                            print(f'New waypoint: {next_waypoint}')
                            dest_lat, dest_lon = next_waypoint
                            Koers_desired = Route.CourseBetweenWaypoints(p1, p2)
                            distance_from_waypoint = Route.DistanceBetweenWaypoints(p1, p2)
                            print(f'Waypoint Koers desired: {Koers_desired}')
                            print(f'Waypoint distance: {distance_from_waypoint}')
                        else:
                            print('End of route')
                            dest_lat, dest_lon = 0, 0
                
            elif pgn == 61445:
                new_lat = struct.unpack('l', iframe.data[:4])[0]/10000000
                new_lon = struct.unpack('l', iframe.data[4:8])[0]/10000000
                print(f' Desired pos: {new_lat} , {new_lon}')
                
                if new_lat == 0 and new_lon == 0:
                    Route.ClearWaypointList()
                    dest_lat, dest_lon = 0, 0
                else:
                    Route.AddWaypoint((new_lat, new_lon))

                    if dest_lat == 0: # no current waypoint
                        dest_lat, dest_lon = Route.NextWaypoint()

                        if current_lat != 0: # position available
                            p1 = current_lat, current_lon
                            p2 = dest_lat, dest_lon
                            
                            Koers_desired = Route.CourseBetweenWaypoints(p1, p2)
                            distance_from_waypoint = Route.DistanceBetweenWaypoints(p1, p2)
                            print(f'Waypoint Koers desired: {Koers_desired}')
                            print(f'Waypoint distance: {distance_from_waypoint}')
                
            elif pgn == 127488 :
                val = iframe.data[1] + iframe.data[2]*256/100
                #print(f'Motor perc: {val}')
                if ControlMode == 1 or ControlMode == 2:
                    ESC.WALnaarESC(val)
                
            elif pgn == 61444:
                ControlMode = iframe.data[0]
                print(f'Control mode: {ControlMode}')
                
            elif pgn == 61440:
                Kp = struct.unpack('f', iframe.data[:4])[0]
                Koers.Kp = Kp
                #print(f'Kp: {Kp}')
                
            elif pgn == 61441:
                Ki = struct.unpack('f', iframe.data[:4])[0]
                Koers.Ki = Ki
                #print(f'Ki: {Ki}')
                
            elif pgn == 61442:
                Kd = struct.unpack('f', iframe.data[:4])[0]
                Koers.Kd = Kd
                #print(f'Kd: {Kd}')
                
except KeyboardInterrupt:
    pass